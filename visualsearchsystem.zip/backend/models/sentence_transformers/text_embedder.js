import { PythonShell } from "python-shell"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

/**
 * Generate text embedding using SentenceTransformers
 * @param {string} text - Input text to embed
 * @returns {Promise<number[]>} - Text embedding vector
 */
export const embedText = async (text) => {
  return new Promise((resolve, reject) => {
    console.log("[v0] Generating text embedding with SentenceTransformers...")

    const options = {
      mode: "text",
      pythonPath: "python3", // or 'python' depending on system
      pythonOptions: ["-u"], // unbuffered stdout
      scriptPath: __dirname,
      args: [],
    }

    const pyshell = new PythonShell("text_embedder.py", options)

    // Send text data to Python script
    pyshell.send(JSON.stringify({ text: text }))

    let result = ""

    pyshell.on("message", (message) => {
      console.log("[v0] Python text embedding output:", message)
      result += message
    })

    pyshell.end((err, code, signal) => {
      if (err) {
        console.error("[v0] Python text embedding error:", err)
        reject(new Error(`Text embedding failed: ${err.message}`))
        return
      }

      try {
        // Parse the embedding result
        const embedding = JSON.parse(result.trim())
        if (!Array.isArray(embedding)) {
          throw new Error("Invalid text embedding format received from Python")
        }

        console.log("[v0] Successfully generated text embedding, dimension:", embedding.length)
        resolve(embedding)
      } catch (parseError) {
        console.error("[v0] Failed to parse text embedding result:", parseError)
        reject(new Error(`Failed to parse text embedding: ${parseError.message}`))
      }
    })
  })
}
