from sentence_transformers import SentenceTransformer
import json
import sys

class TextEmbedder:
    def __init__(self, model_name="all-MiniLM-L6-v2"):
        print(f"🚀 Loading SentenceTransformer model: {model_name}", file=sys.stderr)
        self.model = SentenceTransformer(model_name)
    
    def embed_text(self, text):
        try:
            # Generate embedding
            embedding = self.model.encode(text, convert_to_tensor=False)
            # Convert to list for JSON serialization
            return embedding.tolist()
        except Exception as e:
            raise RuntimeError(f"Text embedding failed: {str(e)}")

# ✅ Singleton pattern — load model once
_embedder = None

def embed_text(text):
    global _embedder
    if _embedder is None:
        _embedder = TextEmbedder()
    return _embedder.embed_text(text)

# Main execution for Node.js integration
if __name__ == "__main__":
    try:
        # Read input from Node.js
        for line in sys.stdin:
            data = json.loads(line.strip())
            text = data.get('text')
            
            if not text:
                raise ValueError("No text provided")
            
            # Process embedding
            embedding = embed_text(text)
            
            # Output result as JSON
            print(json.dumps(embedding))
            break
            
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
