import { PythonShell } from "python-shell"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

/**
 * Process image embedding using OpenCLIP Python model
 * @param {Buffer} imageBuffer - Image data as buffer
 * @returns {Promise<number[]>} - Image embedding vector
 */
export const processImageEmbedding = async (imageBuffer) => {
  return new Promise((resolve, reject) => {
    console.log("[v0] Processing image embedding with OpenCLIP...")

    const options = {
      mode: "text",
      pythonPath: "python3", // or 'python' depending on system
      pythonOptions: ["-u"], // unbuffered stdout
      scriptPath: __dirname,
      args: [],
    }

    const pyshell = new PythonShell("image_embedder.py", options)

    // Send image data as base64 to Python script
    const base64Image = imageBuffer.toString("base64")
    pyshell.send(JSON.stringify({ image_data: base64Image }))

    let result = ""

    pyshell.on("message", (message) => {
      console.log("[v0] Python output:", message)
      result += message
    })

    pyshell.end((err, code, signal) => {
      if (err) {
        console.error("[v0] Python script error:", err)
        reject(new Error(`OpenCLIP embedding failed: ${err.message}`))
        return
      }

      try {
        // Parse the embedding result
        const embedding = JSON.parse(result.trim())
        if (!Array.isArray(embedding)) {
          throw new Error("Invalid embedding format received from Python")
        }

        console.log("[v0] Successfully generated image embedding, dimension:", embedding.length)
        resolve(embedding)
      } catch (parseError) {
        console.error("[v0] Failed to parse embedding result:", parseError)
        reject(new Error(`Failed to parse embedding: ${parseError.message}`))
      }
    })
  })
}
