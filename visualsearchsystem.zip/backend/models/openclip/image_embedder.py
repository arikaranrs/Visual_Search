import open_clip
import torch
from PIL import Image
import io
import json
import sys
import base64

class OpenCLIPEmbedder:
    def __init__(self, model_name="ViT-B-32", pretrained="laion2b_s34b_b79k"):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"🚀 Loading OpenCLIP model: {model_name} ({pretrained}) on {self.device}", file=sys.stderr)
        
        # ✅ CORRECT API: create_model_and_transforms
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name,
            pretrained=pretrained,
            device=self.device
        )
        self.model.eval()  # set to inference mode

    def embed_image(self, image_bytes):
        try:
            # Open image from bytes
            image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            
            # Preprocess image (resize, normalize, etc.)
            image_tensor = self.preprocess(image).unsqueeze(0).to(self.device)

            # Generate embedding
            with torch.no_grad(), torch.cuda.amp.autocast():
                embedding = self.model.encode_image(image_tensor)
                # Normalize embedding (for cosine similarity)
                embedding /= embedding.norm(dim=-1, keepdim=True)

            # Return as list of floats
            return embedding.cpu().numpy().flatten().tolist()

        except Exception as e:
            raise RuntimeError(f"OpenCLIP embedding failed: {str(e)}")

# ✅ Singleton pattern — load model once
_embedder = None

def process_image_embedding(image_buffer):
    global _embedder
    if _embedder is None:
        _embedder = OpenCLIPEmbedder()
    return _embedder.embed_image(image_buffer)

# Main execution for Node.js integration
if __name__ == "__main__":
    try:
        # Read input from Node.js
        for line in sys.stdin:
            data = json.loads(line.strip())
            image_data = data.get('image_data')
            
            if not image_data:
                raise ValueError("No image_data provided")
            
            # Decode base64 image
            image_bytes = base64.b64decode(image_data)
            
            # Process embedding
            embedding = process_image_embedding(image_bytes)
            
            # Output result as JSON
            print(json.dumps(embedding))
            break
            
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
