import open_clip
import torch
import torch.nn.functional as F
from PIL import Image, ImageEnhance, ImageFilter
import io
import json
import sys
import base64
import numpy as np
from torchvision import transforms

class EnhancedOpenCLIPEmbedder:
    def __init__(self, model_name="ViT-B-32", pretrained="laion2b_s34b_b79k"):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"🚀 Loading Enhanced OpenCLIP model: {model_name} ({pretrained}) on {self.device}", file=sys.stderr)
        
        # Load the model with enhanced preprocessing
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name,
            pretrained=pretrained,
            device=self.device
        )
        self.model.eval()
        
        self.enhanced_preprocess = transforms.Compose([
            transforms.Resize((224, 224), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=(0.48145466, 0.4578275, 0.40821073),
                std=(0.26862954, 0.26130258, 0.27577711)
            )
        ])
        
        self.scales = [224, 256, 288]

    def preprocess_image(self, image):
        """Enhanced image preprocessing with multiple augmentations"""
        # Convert to RGB if needed
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Enhance contrast and sharpness for product images
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(1.2)
        
        enhancer = ImageEnhance.Sharpness(image)
        image = enhancer.enhance(1.1)
        
        return image

    def embed_image_multiscale(self, image_bytes):
        """Generate embeddings using multiple scales for better accuracy"""
        try:
            # Open and preprocess image
            image = Image.open(io.BytesIO(image_bytes))
            image = self.preprocess_image(image)
            
            embeddings = []
            
            for scale in self.scales:
                # Resize image to current scale
                resized_image = image.resize((scale, scale), Image.Resampling.BICUBIC)
                
                # Apply preprocessing
                image_tensor = self.enhanced_preprocess(resized_image).unsqueeze(0).to(self.device)
                
                # Generate embedding
                with torch.no_grad(), torch.cuda.amp.autocast():
                    embedding = self.model.encode_image(image_tensor)
                    # L2 normalize for cosine similarity
                    embedding = F.normalize(embedding, p=2, dim=-1)
                    embeddings.append(embedding)
            
            # Give more weight to the standard 224x224 scale
            weights = torch.tensor([0.5, 0.3, 0.2]).to(self.device)
            combined_embedding = torch.zeros_like(embeddings[0])
            
            for i, embedding in enumerate(embeddings):
                combined_embedding += weights[i] * embedding
            
            # Final normalization
            combined_embedding = F.normalize(combined_embedding, p=2, dim=-1)
            
            return combined_embedding.cpu().numpy().flatten().tolist()
            
        except Exception as e:
            raise RuntimeError(f"Enhanced OpenCLIP embedding failed: {str(e)}")

    def embed_image(self, image_bytes):
        """Standard single-scale embedding for compatibility"""
        try:
            image = Image.open(io.BytesIO(image_bytes))
            image = self.preprocess_image(image)
            
            # Standard preprocessing
            image_tensor = self.preprocess(image).unsqueeze(0).to(self.device)
            
            with torch.no_grad(), torch.cuda.amp.autocast():
                embedding = self.model.encode_image(image_tensor)
                embedding = F.normalize(embedding, p=2, dim=-1)
            
            return embedding.cpu().numpy().flatten().tolist()
            
        except Exception as e:
            raise RuntimeError(f"OpenCLIP embedding failed: {str(e)}")

_enhanced_embedder = None

def process_enhanced_image_embedding(image_buffer, use_multiscale=True):
    global _enhanced_embedder
    if _enhanced_embedder is None:
        _enhanced_embedder = EnhancedOpenCLIPEmbedder()
    
    if use_multiscale:
        return _enhanced_embedder.embed_image_multiscale(image_buffer)
    else:
        return _enhanced_embedder.embed_image(image_buffer)

# Main execution for Node.js integration
if __name__ == "__main__":
    try:
        for line in sys.stdin:
            data = json.loads(line.strip())
            image_data = data.get('image_data')
            use_multiscale = data.get('use_multiscale', True)
            
            if not image_data:
                raise ValueError("No image_data provided")
            
            # Decode base64 image
            image_bytes = base64.b64decode(image_data)
            
            # Process embedding with enhanced features
            embedding = process_enhanced_image_embedding(image_bytes, use_multiscale)
            
            # Output result as JSON
            print(json.dumps(embedding))
            break
            
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
