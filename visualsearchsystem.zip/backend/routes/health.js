import express from "express"
import { algoliaSearch } from "../services/algoliaClient.js"
import { queryFaissIndex } from "../vector_db/faiss_index/query_index.js"
import { db } from "../services/metadataFetcher.js"
import { GoogleGenerativeAI } from "@google/generative-ai"

const router = express.Router()

/**
 * GET /api/health
 * Checks connectivity to ALL critical services.
 * Returns 200 OK only if ALL services respond.
 * Returns 503 + error details if ANY service fails.
 */
router.get("/", async (req, res) => {
  const checks = {
    firestore: false,
    algolia: false,
    faiss: false,
    gemini: false,
    python_models: false,
  }

  const startTime = Date.now()

  try {
    // 1. Check Firestore (Firebase) — real query
    console.log("[v0] Health check: Testing Firestore...")
    const snapshot = await db.collection("products").limit(1).get()
    checks.firestore = true
    console.log("[v0] Firestore check passed")
  } catch (error) {
    console.error("[v0] Firestore health check failed:", error.message)
    return res.status(503).json({
      status: "DOWN",
      error: `Firestore connection failed: ${error.message}`,
      checks,
      response_time_ms: Date.now() - startTime,
    })
  }

  try {
    // 2. Check Algolia — real search
    console.log("[v0] Health check: Testing Algolia...")
    await algoliaSearch("healthcheck")
    checks.algolia = true
    console.log("[v0] Algolia check passed")
  } catch (error) {
    console.error("[v0] Algolia health check failed:", error.message)
    return res.status(503).json({
      status: "DOWN",
      error: `Algolia search failed: ${error.message}`,
      checks,
      response_time_ms: Date.now() - startTime,
    })
  }

  try {
    // 3. Check FAISS — test with dummy embedding
    console.log("[v0] Health check: Testing FAISS...")
    const dummyEmbedding = new Array(512).fill(0.1) // Standard embedding dimension
    await queryFaissIndex(dummyEmbedding, 1)
    checks.faiss = true
    console.log("[v0] FAISS check passed")
  } catch (error) {
    console.error("[v0] FAISS health check failed:", error.message)
    return res.status(503).json({
      status: "DOWN",
      error: `FAISS index failed: ${error.message}`,
      checks,
      response_time_ms: Date.now() - startTime,
    })
  }

  try {
    // 4. Check Python models availability
    console.log("[v0] Health check: Testing Python models...")
    const { embedText } = await import("../models/sentence_transformers/text_embedder.js")
    await embedText("health check")
    checks.python_models = true
    console.log("[v0] Python models check passed")
  } catch (error) {
    console.warn("[v0] Python models health check failed:", error.message)
    checks.python_models = `FAILED: ${error.message}`
  }

  try {
    // 5. Check Gemini Vision API — if key provided
    if (process.env.GOOGLE_VISION_API_KEY) {
      console.log("[v0] Health check: Testing Gemini Vision API...")
      const genAI = new GoogleGenerativeAI(process.env.GOOGLE_VISION_API_KEY)
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })
      // Simple prompt to validate API key/quota
      const result = await model.generateContent("Say 'OK'")
      checks.gemini = true
      console.log("[v0] Gemini Vision API check passed")
    } else {
      checks.gemini = "DISABLED (no API key)"
      console.log("[v0] Gemini Vision API disabled - no API key provided")
    }
  } catch (error) {
    console.error("[v0] Gemini Vision API health check failed:", error.message)
    checks.gemini = `FAILED: ${error.message}`
  }

  // All critical services status
  const responseTime = Date.now() - startTime
  const criticalServicesUp = checks.firestore && checks.algolia && checks.faiss

  if (criticalServicesUp) {
    res.status(200).json({
      status: "OK",
      uptime_seconds: Math.floor(process.uptime()),
      response_time_ms: responseTime,
      checks,
      timestamp: new Date().toISOString(),
      version: "1.0.0",
    })
  } else {
    res.status(503).json({
      status: "DEGRADED",
      error: "One or more critical services are down",
      uptime_seconds: Math.floor(process.uptime()),
      response_time_ms: responseTime,
      checks,
      timestamp: new Date().toISOString(),
    })
  }
})

export default router
