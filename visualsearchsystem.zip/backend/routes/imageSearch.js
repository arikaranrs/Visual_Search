import express from "express"
import multer from "multer"
import { processImageEmbedding } from "../../models/openclip/image_embedder.js"
import { vectorSearchByEmbedding } from "../services/vectorSearch.js"
import { aggregateResults } from "../services/aggregateResults.js"
import { enrichWithVisionAPI } from "../services/visionEnrichment.js"

const router = express.Router()

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
})

router.post("/", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No image file provided" })
    }

    console.log("[v0] Enhanced image search request - file size:", req.file.size, "type:", req.file.mimetype)

    const imageBuffer = req.file.buffer
    let vectorResults = []
    let visionResults = []

    try {
      const { processEnhancedImageEmbedding } = await import("../../models/openclip/enhanced_image_embedder.js")
      const embedding = await processEnhancedImageEmbedding(imageBuffer, true) // Use multi-scale

      const { enhancedVectorSearch } = await import("../services/enhanced_vector_search.js")
      vectorResults = await enhancedVectorSearch(embedding, 25, 0.35) // Higher threshold for better accuracy

      console.log("[v0] Enhanced vector search results for image:", vectorResults.length)
    } catch (vectorError) {
      console.warn("[v0] Enhanced vector search failed, falling back to standard search:", vectorError.message)

      // Fallback to standard embedding
      try {
        const embedding = await processImageEmbedding(imageBuffer)
        vectorResults = await vectorSearchByEmbedding(embedding)
      } catch (fallbackError) {
        console.warn("[v0] Standard vector search also failed:", fallbackError.message)
      }
    }

    // Optional: Enrich with Google Vision API
    if (process.env.GOOGLE_VISION_API_KEY) {
      try {
        const visionTags = await enrichWithVisionAPI(imageBuffer)
        console.log("[v0] Vision API tags:", visionTags)

        // Search for products based on vision tags
        if (visionTags && visionTags.length > 0) {
          const { algoliaSearch } = await import("../services/algoliaClient.js")
          const visionQuery = visionTags.join(" ")
          visionResults = await algoliaSearch(visionQuery)
          console.log("[v0] Vision-based search results:", visionResults.length)
        }
      } catch (visionError) {
        console.warn("[v0] Vision API failed:", visionError.message)
      }
    }

    const searchResults = {
      vector: vectorResults,
      vision: visionResults,
    }

    const products = await aggregateResults(searchResults, 20) // Limit to top 20 results

    res.json({
      products,
      query: "Enhanced Image Search",
      searchType: "image",
      sources: {
        vector: vectorResults.length,
        vision: visionResults.length,
        total: products.length,
      },
      performance: {
        averageConfidence:
          products.length > 0 ? products.reduce((sum, p) => sum + (p.searchScore || 0), 0) / products.length : 0,
        highConfidenceResults: products.filter((p) => (p.searchScore || 0) > 0.7).length,
      },
    })
  } catch (error) {
    console.error("[v0] Enhanced image search error:", error)
    res.status(500).json({
      error: "Enhanced image search failed",
      details: error.message,
    })
  }
})

export default router
