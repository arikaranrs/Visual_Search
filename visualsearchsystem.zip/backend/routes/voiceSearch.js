import express from "express"
import { algoliaSearch } from "../services/algoliaClient.js"
import { vectorSearchByText } from "../services/vectorSearch.js"
import { aggregateResults } from "../services/aggregateResults.js"

const router = express.Router()

/**
 * POST /api/voice
 * Accepts transcribed voice as { transcript: "..." } from frontend Web Speech API
 * Delegates to text search pipeline — NO MOCK, NO DUMMY
 */
router.post("/", async (req, res) => {
  const { transcript } = req.body

  if (!transcript || typeof transcript !== "string" || transcript.trim().length === 0) {
    return res.status(400).json({
      error: 'Voice transcript missing or invalid. Send { "transcript": "your words" }',
    })
  }

  try {
    console.log("[v0] Voice search request:", transcript)

    // 1. Search via Algolia (lexical)
    let algoliaResults = []
    try {
      algoliaResults = await algoliaSearch(transcript)
      console.log("[v0] Algolia results for voice:", algoliaResults.length)
    } catch (algoliaError) {
      console.warn("[v0] Algolia search failed for voice:", algoliaError.message)
    }

    // 2. Optional: Semantic vector search
    let vectorResults = []
    if (process.env.USE_SEMANTIC === "true") {
      try {
        const { embedText } = await import("../../models/sentence_transformers/text_embedder.js")
        const embedding = await embedText(transcript)
        vectorResults = await vectorSearchByText(embedding)
        console.log("[v0] Vector search results for voice:", vectorResults.length)
      } catch (vectorError) {
        console.warn("[v0] Vector search failed for voice:", vectorError.message)
      }
    }

    // 3. Aggregate + fetch real metadata
    const searchResults = {
      algolia: algoliaResults,
      vector: vectorResults,
    }

    const products = await aggregateResults(searchResults)

    // Return real product results
    res.json({
      products,
      query: transcript,
      searchType: "voice",
      sources: {
        algolia: algoliaResults.length,
        vector: vectorResults.length,
        total: products.length,
      },
    })
  } catch (error) {
    console.error("[v0] Voice Search Failed:", error.message)
    res.status(500).json({
      error: "Voice search failed",
      details: error.message,
    })
  }
})

export default router
