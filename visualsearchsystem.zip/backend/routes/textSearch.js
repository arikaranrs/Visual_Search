import express from "express"
import { algoliaSearch } from "../services/algoliaClient.js"
import { vectorSearchByText } from "../services/vectorSearch.js"
import { aggregateResults } from "../services/aggregateResults.js"

const router = express.Router()

router.post("/", async (req, res) => {
  const { query } = req.body
  if (!query) return res.status(400).json({ error: "Missing query parameter" })

  try {
    console.log("[v0] Text search request:", query)

    // Search with Algolia
    let algoliaResults = []
    try {
      algoliaResults = await algoliaSearch(query)
      console.log("[v0] Algolia results:", algoliaResults.length)
    } catch (algoliaError) {
      console.warn("[v0] Algolia search failed:", algoliaError.message)
    }

    // Search with semantic/vector search if enabled
    let vectorResults = []
    if (process.env.USE_SEMANTIC === "true") {
      try {
        const { embedText } = await import("../../models/sentence_transformers/text_embedder.js")
        const embedding = await embedText(query)
        vectorResults = await vectorSearchByText(embedding)
        console.log("[v0] Vector search results:", vectorResults.length)
      } catch (vectorError) {
        console.warn("[v0] Vector search failed:", vectorError.message)
      }
    }

    // Aggregate results from all sources
    const searchResults = {
      algolia: algoliaResults,
      vector: vectorResults,
    }

    const products = await aggregateResults(searchResults)

    res.json({
      products,
      query,
      searchType: "text",
      sources: {
        algolia: algoliaResults.length,
        vector: vectorResults.length,
        total: products.length,
      },
    })
  } catch (error) {
    console.error("[v0] Text search error:", error)
    res.status(500).json({
      error: "Text search failed",
      details: error.message,
    })
  }
})

export default router
