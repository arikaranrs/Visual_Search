import { PythonShell } from "python-shell"
import path from "path"
import { fileURLToPath } from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

/**
 * Query FAISS index for similar vectors
 * @param {number[]} embedding - Query embedding vector
 * @param {number} k - Number of results to return
 * @returns {Promise<Array>} - Array of similar items with IDs and distances
 */
export const queryFaissIndex = async (embedding, k = 20) => {
  return new Promise((resolve, reject) => {
    console.log("[v0] Querying FAISS index...")

    const options = {
      mode: "text",
      pythonPath: "python3",
      pythonOptions: ["-u"],
      scriptPath: __dirname,
      args: [],
    }

    const pyshell = new PythonShell("query_index.py", options)

    // Send query data to Python script
    pyshell.send(
      JSON.stringify({
        embedding: embedding,
        k: k,
      }),
    )

    let result = ""

    pyshell.on("message", (message) => {
      console.log("[v0] FAISS query output:", message)
      result += message
    })

    pyshell.end((err, code, signal) => {
      if (err) {
        console.error("[v0] FAISS query error:", err)
        reject(new Error(`FAISS query failed: ${err.message}`))
        return
      }

      try {
        // Parse the query result
        const queryResults = JSON.parse(result.trim())
        if (!Array.isArray(queryResults)) {
          throw new Error("Invalid FAISS query result format")
        }

        console.log("[v0] FAISS query returned", queryResults.length, "results")
        resolve(queryResults)
      } catch (parseError) {
        console.error("[v0] Failed to parse FAISS query result:", parseError)
        reject(new Error(`Failed to parse FAISS result: ${parseError.message}`))
      }
    })
  })
}

/**
 * Singleton FAISS index interface
 */
class FaissIndexInterface {
  async search(embedding, k = 20) {
    return await queryFaissIndex(embedding, k)
  }
}

let _faissIndex = null

export const getFaissIndex = () => {
  if (_faissIndex === null) {
    _faissIndex = new FaissIndexInterface()
  }
  return _faissIndex
}
