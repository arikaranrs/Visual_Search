import faiss
import pickle
import os
import numpy as np
import json
import sys
from sklearn.preprocessing import normalize

# Check if index files exist
if not os.path.exists("faiss_index.bin") or not os.path.exists("id_map.pkl"):
    print(json.dumps({"error": "FAISS index files not found. Please build index first."}), file=sys.stderr)
    sys.exit(1)

class EnhancedFaissIndex:
    def __init__(self):
        try:
            self.index = faiss.read_index("faiss_index.bin")
            with open("id_map.pkl", "rb") as f:
                self.id_map = pickle.load(f)
            print(f"✅ Enhanced FAISS index loaded: {self.index.ntotal} vectors", file=sys.stderr)
            
            self.metadata = {}
            if os.path.exists("product_metadata.pkl"):
                with open("product_metadata.pkl", "rb") as f:
                    self.metadata = pickle.load(f)
                    
        except Exception as e:
            raise RuntimeError(f"Failed to load enhanced FAISS index: {str(e)}")

    def enhanced_search(self, embedding, k=20, similarity_threshold=0.3):
        try:
            emb = np.array(embedding).astype('float32').reshape(1, -1)
            
            # Ensure embedding is normalized
            emb = normalize(emb, norm='l2', axis=1)
            
            search_k = min(k * 3, self.index.ntotal)
            distances, indices = self.index.search(emb, search_k)
            
            results = []
            for i in range(len(indices[0])):
                if indices[0][i] != -1:  # Valid result
                    distance = float(distances[0][i])
                    
                    cosine_similarity = float(1.0 / (1.0 + distance))
                    euclidean_similarity = float(1.0 / (1.0 + np.sqrt(distance)))
                    
                    # Combined similarity score
                    combined_similarity = (cosine_similarity * 0.7 + euclidean_similarity * 0.3)
                    
                    if combined_similarity >= similarity_threshold:
                        product_id = self.id_map[indices[0][i]]
                        
                        result = {
                            'id': product_id,
                            'distance': distance,
                            'similarity': combined_similarity,
                            'cosine_similarity': cosine_similarity,
                            'euclidean_similarity': euclidean_similarity,
                            'rank': i + 1
                        }
                        
                        if product_id in self.metadata:
                            result['category'] = self.metadata[product_id].get('category', 'unknown')
                            result['brand'] = self.metadata[product_id].get('brand', 'unknown')
                        
                        results.append(result)
            
            results.sort(key=lambda x: (
                x['similarity'] * 0.6 +  # Primary similarity
                (1.0 / x['rank']) * 0.2 +  # Rank bonus
                (0.2 if x.get('category') != 'unknown' else 0)  # Metadata bonus
            ), reverse=True)
            
            return results[:k]
            
        except Exception as e:
            raise RuntimeError(f"Enhanced FAISS search failed: {str(e)}")

_enhanced_index = None

def get_enhanced_faiss_index():
    global _enhanced_index
    if _enhanced_index is None:
        _enhanced_index = EnhancedFaissIndex()
    return _enhanced_index

# Main execution for Node.js integration
if __name__ == "__main__":
    try:
        for line in sys.stdin:
            data = json.loads(line.strip())
            embedding = data.get('embedding')
            k = data.get('k', 20)
            similarity_threshold = data.get('similarity_threshold', 0.3)
            
            if not embedding:
                raise ValueError("No embedding provided")
            
            # Perform enhanced search
            index = get_enhanced_faiss_index()
            results = index.enhanced_search(embedding, k, similarity_threshold)
            
            # Output result as JSON
            print(json.dumps(results))
            break
            
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
