import faiss
import pickle
import os
import numpy as np
import json
import sys

# Check if index files exist
if not os.path.exists("faiss_index.bin") or not os.path.exists("id_map.pkl"):
    print(json.dumps({"error": "FAISS index files not found. Please build index first."}), file=sys.stderr)
    sys.exit(1)

class FaissIndex:
    def __init__(self):
        try:
            self.index = faiss.read_index("faiss_index.bin")
            with open("id_map.pkl", "rb") as f:
                self.id_map = pickle.load(f)
            print(f"✅ FAISS index loaded: {self.index.ntotal} vectors", file=sys.stderr)
        except Exception as e:
            raise RuntimeError(f"Failed to load FAISS index: {str(e)}")

    def search(self, embedding, k=20):
        try:
            # Ensure embedding is the right format
            emb = np.array(embedding).astype('float32').reshape(1, -1)
            
            # Perform search
            distances, indices = self.index.search(emb, k)
            
            # Format results
            results = []
            for i in range(len(indices[0])):
                if indices[0][i] != -1:  # Valid result
                    results.append({
                        'id': self.id_map[indices[0][i]], 
                        'distance': float(distances[0][i]),
                        'similarity': float(1.0 / (1.0 + distances[0][i]))  # Convert distance to similarity
                    })
            
            return results
            
        except Exception as e:
            raise RuntimeError(f"FAISS search failed: {str(e)}")

# ✅ Singleton pattern — load index once
_index = None

def get_faiss_index():
    global _index
    if _index is None:
        _index = FaissIndex()
    return _index

# Main execution for Node.js integration
if __name__ == "__main__":
    try:
        # Read input from Node.js
        for line in sys.stdin:
            data = json.loads(line.strip())
            embedding = data.get('embedding')
            k = data.get('k', 20)
            
            if not embedding:
                raise ValueError("No embedding provided")
            
            # Perform search
            index = get_faiss_index()
            results = index.search(embedding, k)
            
            # Output result as JSON
            print(json.dumps(results))
            break
            
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
