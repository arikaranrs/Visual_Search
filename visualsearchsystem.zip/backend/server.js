import express from "express"
import cors from "cors"
import { json, urlencoded } from "express"
import path from "path"
import { fileURLToPath } from "url"

// Import Routes
import textSearchRouter from "./routes/textSearch.js"
import voiceSearchRouter from "./routes/voiceSearch.js"
import imageSearchRouter from "./routes/imageSearch.js"
import healthRouter from "./routes/health.js"

// Initialize Express
const app = express()
const PORT = process.env.PORT || 3001

// Resolve __dirname for ES Modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Middleware
app.use(cors()) // Allow frontend requests
app.use(json({ limit: "10mb" })) // For JSON bodies (voice, autocomplete)
app.use(urlencoded({ extended: true })) // For URL-encoded forms
app.use("/uploads", express.static(path.join(__dirname, "uploads"))) // Optional: serve uploaded files

// Health Check — FIRST route (critical for uptime monitoring)
app.use("/api/health", healthRouter)

// API Routes
app.use("/api/text", textSearchRouter)
app.use("/api/voice", voiceSearchRouter)
app.use("/api/image", imageSearchRouter)

// Optional: Serve static files (if you build React into /public)
// app.use(express.static(path.join(__dirname, '../public')));
// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, '../public/index.html'));
// });

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.url} not found` })
})

// Global Error Handler
app.use((error, req, res, next) => {
  console.error("❌ Global Error:", error.stack || error.message)
  res.status(500).json({
    error: "Internal Server Error",
    message: process.env.NODE_ENV === "development" ? error.message : undefined,
  })
})

// Graceful Shutdown
const shutdown = () => {
  console.log("🔌 Shutting down server...")
  process.exit(0)
}

process.on("SIGTERM", shutdown)
process.on("SIGINT", shutdown)

// Start Server — but ONLY if all critical services are ready
;(async () => {
  try {
    console.log("[v0] Validating critical services on startup...")

    // Test Algolia
    const { algoliaSearch } = await import("./services/algoliaClient.js")
    await algoliaSearch("startup")
    console.log("[v0] ✅ Algolia validated")

    // Test FAISS index
    const { queryFaissIndex } = await import("./vector_db/faiss_index/query_index.js")
    const dummyEmbedding = new Array(512).fill(0.1)
    await queryFaissIndex(dummyEmbedding, 1)
    console.log("[v0] ✅ FAISS index validated")

    // Test Firebase
    const { db } = await import("./services/metadataFetcher.js")
    await db.collection("products").limit(1).get()
    console.log("[v0] ✅ Firebase validated")

    // Test Python models (optional - don't fail startup if unavailable)
    try {
      const { embedText } = await import("./models/sentence_transformers/text_embedder.js")
      await embedText("startup test")
      console.log("[v0] ✅ Python text embedder validated")
    } catch (pythonError) {
      console.warn("[v0] ⚠️ Python models not available:", pythonError.message)
    }

    // Test Gemini Vision API (optional)
    if (process.env.GOOGLE_VISION_API_KEY) {
      try {
        const { GoogleGenerativeAI } = await import("@google/generative-ai")
        const genAI = new GoogleGenerativeAI(process.env.GOOGLE_VISION_API_KEY)
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })
        await model.generateContent("startup")
        console.log("[v0] ✅ Gemini Vision API validated")
      } catch (geminiError) {
        console.warn("[v0] ⚠️ Gemini Vision API not available:", geminiError.message)
      }
    }

    console.log("[v0] ✅ All critical services validated. Starting server...")

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`🚀 Visual Search Backend running at http://localhost:${PORT}`)
      console.log(`📊 Health check: http://localhost:${PORT}/api/health`)
      console.log(`🔍 Text search: POST http://localhost:${PORT}/api/text`)
      console.log(`🎙️ Voice search: POST http://localhost:${PORT}/api/voice`)
      console.log(`📷 Image search: POST http://localhost:${PORT}/api/image`)
    })
  } catch (startupError) {
    console.error("[v0] 🔥 FAILED TO START: Critical service unavailable")
    console.error(startupError.message)
    console.error("Please check your environment variables and service configurations")
    process.exit(1)
  }
})()
