import algoliasearch from 'algoliasearch';

if (!process.env.ALGOLIA_APP_ID || !process.env.ALGOLIA_API_KEY) {
  throw new Error("MISSING ALGOLIA CREDENTIALS");
}

const client = algoliasearch(process.env.ALGOLIA_APP_ID, process.env.ALGOLIA_API_KEY);
const index = client.initIndex(process.env.ALGOLIA_INDEX_NAME || 'products');

export const algoliaSearch = async (q) => {
  const { hits } = await index.search(q, { hitsPerPage: 20 });
  return hits;
};
