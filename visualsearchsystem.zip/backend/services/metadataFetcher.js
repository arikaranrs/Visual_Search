import { initializeApp } from "firebase/app"
import { getFirestore, collection, query, where, getDocs, documentId } from "firebase/firestore"

// Firebase configuration - should match frontend config
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY || process.env.REACT_APP_FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN || process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID || process.env.REACT_APP_FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET || process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID || process.env.REACT_APP_FIREBASE_APP_ID,
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)

/**
 * Fetches product metadata from Firebase Firestore
 * @param {string[]} ids - Array of product IDs to fetch
 * @returns {Object} Object with product IDs as keys and product data as values
 */
export const fetchProductMetadata = async (ids) => {
  try {
    if (!ids || ids.length === 0) {
      console.log("[v0] No product IDs provided to fetchProductMetadata")
      return {}
    }

    console.log(`[v0] Fetching metadata for ${ids.length} products:`, ids)

    // Firebase 'in' queries are limited to 10 items, so we need to batch
    const batches = []
    const batchSize = 10

    for (let i = 0; i < ids.length; i += batchSize) {
      const batchIds = ids.slice(i, i + batchSize)
      batches.push(batchIds)
    }

    const metadata = {}

    // Execute all batches in parallel
    const batchPromises = batches.map(async (batchIds) => {
      const productsRef = collection(db, "products")
      const q = query(productsRef, where(documentId(), "in", batchIds))
      const querySnapshot = await getDocs(q)

      querySnapshot.forEach((doc) => {
        metadata[doc.id] = {
          id: doc.id,
          ...doc.data(),
        }
      })
    })

    await Promise.all(batchPromises)

    console.log(`[v0] Successfully fetched metadata for ${Object.keys(metadata).length} products`)
    return metadata
  } catch (error) {
    console.error("[v0] Error fetching product metadata:", error)
    throw new Error(`Failed to fetch product metadata: ${error.message}`)
  }
}

/**
 * Fetches all products from Firebase (for fallback or testing)
 * @param {number} limit - Maximum number of products to fetch
 * @returns {Array} Array of product objects
 */
export const fetchAllProducts = async (limit = 20) => {
  try {
    console.log(`[v0] Fetching up to ${limit} products from Firebase`)

    const productsRef = collection(db, "products")
    const querySnapshot = await getDocs(productsRef)

    const products = []
    let count = 0

    querySnapshot.forEach((doc) => {
      if (count < limit) {
        products.push({
          id: doc.id,
          ...doc.data(),
        })
        count++
      }
    })

    console.log(`[v0] Fetched ${products.length} products from Firebase`)
    return products
  } catch (error) {
    console.error("[v0] Error fetching all products:", error)
    throw new Error(`Failed to fetch products: ${error.message}`)
  }
}
