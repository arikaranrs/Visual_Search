import { GoogleGenerativeAI } from "@google/generative-ai";

if (!process.env.GOOGLE_VISION_API_KEY) {
  throw new Error("MISSING GOOGLE VISION API KEY");
}

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_VISION_API_KEY);

export const enrichWithVisionAPI = async (imageBuffer) => {
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  const result = await model.generateContent([
    "List objects, colors, materials. Comma-separated.",
    { inlineData: { data: Buffer.from(imageBuffer).toString('base64'), mimeType: 'image/jpeg' } }
  ]);
  return result.response.text().split(',').map(t => t.trim());
};
