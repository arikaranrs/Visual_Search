import { fetchProductMetadata } from "./metadataFetcher.js"

/**
 * Aggregates search results from multiple sources (Algolia, Vector Search, etc.)
 * and enriches them with Firebase metadata
 */
export const aggregateResults = async (searchResults, maxResults = 20) => {
  try {
    console.log("[v0] Aggregating results from multiple sources...")

    // Collect all unique product IDs from different search sources
    const productIds = new Set()
    const scoredResults = []

    // Process Algolia results if available
    if (searchResults.algolia && searchResults.algolia.length > 0) {
      searchResults.algolia.forEach((hit, index) => {
        productIds.add(hit.objectID)
        scoredResults.push({
          id: hit.objectID,
          score: 1.0 - index * 0.1, // Higher score for better ranking
          source: "algolia",
          relevance: hit._highlightResult ? "high" : "medium",
        })
      })
    }

    // Process Vector Search results if available
    if (searchResults.vector && searchResults.vector.length > 0) {
      searchResults.vector.forEach((result, index) => {
        productIds.add(result.id)
        const existingResult = scoredResults.find((r) => r.id === result.id)

        if (existingResult) {
          // Boost score if found in multiple sources
          existingResult.score += 0.5
          existingResult.source += ",vector"
        } else {
          scoredResults.push({
            id: result.id,
            score: result.similarity || 0.8 - index * 0.05,
            source: "vector",
            relevance: result.similarity > 0.8 ? "high" : "medium",
          })
        }
      })
    }

    // Process Vision API results if available
    if (searchResults.vision && searchResults.vision.length > 0) {
      searchResults.vision.forEach((result, index) => {
        productIds.add(result.id)
        const existingResult = scoredResults.find((r) => r.id === result.id)

        if (existingResult) {
          existingResult.score += 0.3
          existingResult.source += ",vision"
        } else {
          scoredResults.push({
            id: result.id,
            score: 0.7 - index * 0.05,
            source: "vision",
            relevance: "medium",
          })
        }
      })
    }

    // If no results from search engines, return empty array
    if (productIds.size === 0) {
      console.log("[v0] No search results to aggregate")
      return []
    }

    // Fetch metadata from Firebase for all unique product IDs
    const productIdsArray = Array.from(productIds)
    console.log(`[v0] Fetching metadata for ${productIdsArray.length} products`)

    const metadata = await fetchProductMetadata(productIdsArray)

    // Combine scores with metadata and sort by relevance
    const enrichedResults = scoredResults
      .filter((result) => metadata[result.id]) // Only include products that exist in Firebase
      .map((result) => ({
        ...metadata[result.id],
        searchScore: result.score,
        searchSource: result.source,
        relevance: result.relevance,
      }))
      .sort((a, b) => b.searchScore - a.searchScore) // Sort by score descending
      .slice(0, maxResults) // Limit results

    console.log(`[v0] Aggregated ${enrichedResults.length} results`)
    return enrichedResults
  } catch (error) {
    console.error("[v0] Error aggregating results:", error)
    throw new Error(`Failed to aggregate search results: ${error.message}`)
  }
}

/**
 * Fallback function to get sample products when search fails
 */
export const getFallbackProducts = async (limit = 8) => {
  try {
    console.log("[v0] Getting fallback products from Firebase")

    // This would typically get trending or featured products
    // For now, we'll return empty array to force proper Firebase setup
    return []
  } catch (error) {
    console.error("[v0] Error getting fallback products:", error)
    return []
  }
}
