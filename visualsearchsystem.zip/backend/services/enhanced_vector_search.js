import { spawn } from "child_process"
import path from "path"

/**
 * Enhanced vector search with improved similarity scoring and filtering
 */
export const enhancedVectorSearch = async (embedding, k = 20, similarityThreshold = 0.3) => {
  return new Promise((resolve, reject) => {
    console.log("[v0] Starting enhanced vector search...")

    const pythonScript = path.join(process.cwd(), "backend/vector_db/faiss_index/enhanced_query_index.py")
    const pythonProcess = spawn("python", [pythonScript])

    let output = ""
    let errorOutput = ""

    pythonProcess.stdout.on("data", (data) => {
      output += data.toString()
    })

    pythonProcess.stderr.on("data", (data) => {
      errorOutput += data.toString()
    })

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        console.error("[v0] Enhanced vector search failed:", errorOutput)
        reject(new Error(`Enhanced vector search failed: ${errorOutput}`))
        return
      }

      try {
        const results = JSON.parse(output.trim())

        if (results.error) {
          reject(new Error(results.error))
          return
        }

        const filteredResults = results
          .filter((result) => result.similarity >= similarityThreshold)
          .map((result) => ({
            id: result.id,
            similarity: result.similarity,
            distance: result.distance,
            confidence: calculateConfidenceScore(result.similarity),
            relevanceScore: result.similarity * 0.8 + (result.similarity > 0.7 ? 0.2 : 0),
          }))
          .sort((a, b) => b.relevanceScore - a.relevanceScore)
          .slice(0, k)

        console.log(`[v0] Enhanced vector search completed: ${filteredResults.length} results`)
        resolve(filteredResults)
      } catch (parseError) {
        console.error("[v0] Failed to parse enhanced vector search results:", parseError)
        reject(new Error("Failed to parse search results"))
      }
    })

    // Send search parameters to Python script
    const searchParams = {
      embedding,
      k: k * 2, // Get more results for better filtering
      similarity_threshold: similarityThreshold,
    }

    pythonProcess.stdin.write(JSON.stringify(searchParams) + "\n")
    pythonProcess.stdin.end()
  })
}

function calculateConfidenceScore(similarity) {
  if (similarity >= 0.85) return "high"
  if (similarity >= 0.65) return "medium"
  if (similarity >= 0.45) return "low"
  return "very_low"
}

export const vectorSearchByEmbedding = enhancedVectorSearch
