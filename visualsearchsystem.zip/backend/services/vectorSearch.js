import { queryFaissIndex } from "../vector_db/faiss_index/query_index.js"

/**
 * Search by embedding vector using FAISS index
 * @param {number[]} embedding - Query embedding vector
 * @param {number} k - Number of results to return
 * @returns {Promise<Array>} - Array of search results with IDs and similarities
 */
export const vectorSearchByEmbedding = async (embedding, k = 20) => {
  try {
    console.log("[v0] Performing vector search with embedding dimension:", embedding.length)
    const results = await queryFaissIndex(embedding, k)

    // Transform results to match expected format
    return results.map((result) => ({
      id: result.id,
      similarity: result.similarity,
      distance: result.distance,
    }))
  } catch (error) {
    console.error("[v0] Vector search failed:", error)
    throw new Error(`Vector search failed: ${error.message}`)
  }
}

/**
 * Search by text using text embeddings and vector search
 * @param {number[]} textEmbedding - Pre-computed text embedding
 * @param {number} k - Number of results to return
 * @returns {Promise<Array>} - Array of search results
 */
export const vectorSearchByText = async (textEmbedding, k = 20) => {
  return await vectorSearchByEmbedding(textEmbedding, k)
}
