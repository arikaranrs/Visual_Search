import { config, validateConfig } from "../lib/config"

async function testGoogleVisionAPI() {
  try {
    console.log("[v0] Testing Google Vision API...")

    validateConfig()

    const apiKey = config.googleVision.apiKey
    if (!apiKey) {
      throw new Error("Google Vision API key not configured")
    }

    // Test with a simple image URL
    const testImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Vd-Orig.png/256px-Vd-Orig.png"

    const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        requests: [
          {
            image: {
              source: { imageUri: testImageUrl },
            },
            features: [
              { type: "LABEL_DETECTION", maxResults: 5 },
              { type: "TEXT_DETECTION", maxResults: 5 },
            ],
          },
        ],
      }),
    })

    if (!response.ok) {
      throw new Error(`Vision API error: ${response.status} ${response.statusText}`)
    }

    const result = await response.json()
    console.log("[v0] ✅ Google Vision API connection successful")
    console.log("[v0] Test results:", JSON.stringify(result, null, 2))
  } catch (error) {
    console.error("[v0] ❌ Google Vision API test failed:", error)
    process.exit(1)
  }
}

testGoogleVisionAPI()
