import { config, validateConfig } from "../lib/config"
import { initializeApp, cert } from "firebase-admin/app"
import { getFirestore } from "firebase-admin/firestore"

async function testFirebaseConnection() {
  try {
    console.log("[v0] Testing Firebase connection...")

    validateConfig()

    const serviceAccount = {
      type: "service_account",
      project_id: config.firebase.projectId,
      private_key_id: config.firebase.privateKeyId,
      private_key: config.firebase.privateKey,
      client_email: config.firebase.clientEmail,
      client_id: config.firebase.clientId,
      auth_uri: config.firebase.authUri,
      token_uri: config.firebase.tokenUri,
      auth_provider_x509_cert_url: config.firebase.authProviderX509CertUrl,
      client_x509_cert_url: config.firebase.clientX509CertUrl,
    }

    const app = initializeApp({
      credential: cert(serviceAccount as any),
      projectId: config.firebase.projectId,
    })

    const db = getFirestore(app)

    // Test connection
    const testDoc = await db.collection("test").doc("connection").get()
    console.log("[v0] ✅ Firebase connection successful")

    // Test write
    await db.collection("test").doc("connection").set({
      timestamp: new Date(),
      status: "connected",
    })
    console.log("[v0] ✅ Firebase write test successful")
  } catch (error) {
    console.error("[v0] ❌ Firebase connection failed:", error)
    process.exit(1)
  }
}

testFirebaseConnection()
