import { execSync } from "child_process"

async function fixSecurityIssues(): Promise<void> {
  console.log("🔒 Fixing Security Vulnerabilities...")
  console.log("=".repeat(50))

  try {
    console.log("📋 Running npm audit...")
    execSync("npm audit", { stdio: "inherit" })

    console.log("\n🔧 Applying security fixes...")
    execSync("npm audit fix --force", { stdio: "inherit" })

    console.log("\n📦 Updating vulnerable packages...")
    // Update specific vulnerable packages
    const updates = ["npm update react react-dom", "npm update next", "npm update @types/node", "npm update typescript"]

    for (const update of updates) {
      console.log(`   Running: ${update}`)
      try {
        execSync(update, { stdio: "inherit" })
      } catch (error) {
        console.log(`   ⚠️  Warning: ${update} failed`)
      }
    }

    console.log("\n✅ Security fixes completed")
    console.log("Run 'npm audit' again to verify all issues are resolved")
  } catch (error) {
    console.log("❌ Security fix failed")
    console.log(`Error: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Run if executed directly
if (require.main === module) {
  fixSecurityIssues().catch(console.error)
}

export { fixSecurityIssues }
