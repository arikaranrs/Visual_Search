import { analyzeImageWithEnhancedCNN, extractEnhancedSearchKeywords } from "@/lib/services/enhanced-vision-service"
import { searchSimilarProducts } from "@/lib/services/enhanced-search-service"

export async function testEnhancedImageAccuracy(): Promise<void> {
  console.log("🧠 Testing Enhanced CNN Image Recognition Accuracy")
  console.log("=".repeat(60))

  const testCases = [
    {
      name: "red_sneakers_test",
      expectedKeywords: ["shoe", "sneaker", "red", "athletic", "footwear"],
      expectedCategory: "footwear",
      minSimilarityScore: 0.6,
    },
    {
      name: "blue_jeans_test",
      expectedKeywords: ["jeans", "denim", "blue", "pants", "clothing"],
      expectedCategory: "clothing",
      minSimilarityScore: 0.6,
    },
    {
      name: "black_watch_test",
      expectedKeywords: ["watch", "timepiece", "black", "accessory"],
      expectedCategory: "accessories",
      minSimilarityScore: 0.5,
    },
  ]

  let totalAccuracy = 0
  const totalTests = testCases.length

  for (const testCase of testCases) {
    console.log(`\n🔍 Testing: ${testCase.name}`)

    try {
      // Create test image
      const testImage = await createEnhancedTestImage(testCase.name)

      // Analyze with enhanced CNN
      const startTime = Date.now()
      const analysis = await analyzeImageWithEnhancedCNN(testImage)
      const keywords = extractEnhancedSearchKeywords(analysis)
      const analysisTime = Date.now() - startTime

      // Search for similar products
      const searchStart = Date.now()
      const searchResults = await searchSimilarProducts(keywords, testCase.minSimilarityScore)
      const searchTime = Date.now() - searchStart

      // Calculate accuracy
      const keywordAccuracy = calculateKeywordAccuracy(testCase.expectedKeywords, keywords)
      const categoryMatch = analysis.productCategories.some((cat) =>
        cat.toLowerCase().includes(testCase.expectedCategory.toLowerCase()),
      )

      const overallAccuracy = (keywordAccuracy + (categoryMatch ? 100 : 0)) / 2
      totalAccuracy += overallAccuracy

      console.log(`   Expected Keywords: ${testCase.expectedKeywords.join(", ")}`)
      console.log(`   Detected Keywords: ${keywords.join(", ")}`)
      console.log(`   Product Categories: ${analysis.productCategories.join(", ")}`)
      console.log(`   Color Analysis: ${analysis.colorAnalysis.join(", ")}`)
      console.log(`   Keyword Accuracy: ${keywordAccuracy.toFixed(1)}%`)
      console.log(`   Category Match: ${categoryMatch ? "✅" : "❌"}`)
      console.log(`   Overall Accuracy: ${overallAccuracy.toFixed(1)}%`)
      console.log(`   Analysis Time: ${analysisTime}ms`)
      console.log(`   Search Time: ${searchTime}ms`)
      console.log(`   Similar Products Found: ${searchResults.totalResults}`)
      console.log(`   Search Confidence: ${(searchResults.confidence * 100).toFixed(1)}%`)

      if (overallAccuracy >= 70) {
        console.log("   🎉 Excellent accuracy!")
      } else if (overallAccuracy >= 50) {
        console.log("   ✅ Good accuracy")
      } else {
        console.log("   ⚠️  Needs improvement")
      }
    } catch (error) {
      console.log(`   ❌ Test failed: ${error}`)
    }
  }

  const avgAccuracy = totalAccuracy / totalTests
  console.log(`\n📊 Enhanced CNN Test Results`)
  console.log("=".repeat(60))
  console.log(`Average Accuracy: ${avgAccuracy.toFixed(1)}%`)

  if (avgAccuracy >= 80) {
    console.log("🎉 Outstanding performance! Production ready.")
  } else if (avgAccuracy >= 65) {
    console.log("✅ Good performance. Minor optimizations recommended.")
  } else {
    console.log("⚠️  Performance needs improvement. Check configuration.")
  }
}

async function createEnhancedTestImage(imageName: string): Promise<File> {
  const canvas = document.createElement("canvas")
  canvas.width = 300
  canvas.height = 300
  const ctx = canvas.getContext("2d")!

  // Create more realistic test images
  if (imageName.includes("sneakers")) {
    ctx.fillStyle = "#FF0000" // Red background
    ctx.fillRect(0, 0, 300, 300)
    ctx.fillStyle = "#FFFFFF"
    ctx.fillRect(50, 100, 200, 100) // Shoe shape
    ctx.fillStyle = "#000000"
    ctx.font = "20px Arial"
    ctx.fillText("SNEAKER", 100, 160)
  } else if (imageName.includes("jeans")) {
    ctx.fillStyle = "#0066CC" // Blue background
    ctx.fillRect(0, 0, 300, 300)
    ctx.fillStyle = "#003366"
    ctx.fillRect(80, 50, 140, 200) // Pants shape
    ctx.fillStyle = "#FFFFFF"
    ctx.font = "16px Arial"
    ctx.fillText("DENIM", 120, 160)
  } else if (imageName.includes("watch")) {
    ctx.fillStyle = "#000000" // Black background
    ctx.fillRect(0, 0, 300, 300)
    ctx.fillStyle = "#CCCCCC"
    ctx.beginPath()
    ctx.arc(150, 150, 80, 0, 2 * Math.PI) // Watch face
    ctx.fill()
    ctx.fillStyle = "#000000"
    ctx.font = "14px Arial"
    ctx.fillText("12:00", 130, 155)
  }

  return new Promise((resolve) => {
    canvas.toBlob(
      (blob) => {
        resolve(new File([blob!], imageName + ".jpg", { type: "image/jpeg" }))
      },
      "image/jpeg",
      0.9,
    )
  })
}

function calculateKeywordAccuracy(expected: string[], detected: string[]): number {
  if (expected.length === 0) return 0

  const matches = expected.filter((expectedKeyword) =>
    detected.some(
      (detectedKeyword) =>
        detectedKeyword.toLowerCase().includes(expectedKeyword.toLowerCase()) ||
        expectedKeyword.toLowerCase().includes(detectedKeyword.toLowerCase()),
    ),
  )

  return (matches.length / expected.length) * 100
}
