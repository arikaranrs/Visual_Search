import { testVisionAPI, analyzeImageWithVision } from "@/lib/services/vision-service"
import { config } from "@/lib/config"

async function runVisionAPITests() {
  console.log("🔍 Testing Google Vision API Configuration...")
  console.log("=".repeat(50))

  // Test 1: Configuration check
  console.log("1. Configuration Check:")
  console.log(`   API Key: ${config.googleVision.apiKey ? "✅ Configured" : "❌ Missing"}`)
  console.log(`   Credentials: ${config.googleVision.credentials ? "✅ Configured" : "❌ Missing"}`)
  console.log(`   Project ID: ${config.googleVision.projectId}`)
  console.log(`   Feature Enabled: ${config.features.useVisionApi ? "✅ Yes" : "❌ No"}`)
  console.log()

  // Test 2: API Connectivity
  console.log("2. API Connectivity Test:")
  const connectivityTest = await testVisionAPI()
  if (connectivityTest.success) {
    console.log("   ✅ Vision API is accessible and working")
  } else {
    console.log(`   ❌ Vision API test failed: ${connectivityTest.error}`)
    if (connectivityTest.details) {
      console.log(`   Details:`, connectivityTest.details)
    }
  }
  console.log()

  // Test 3: Sample Image Analysis
  console.log("3. Sample Image Analysis:")
  try {
    // Create a test image blob (simple colored square)
    const canvas = document.createElement?.("canvas") || null
    if (canvas) {
      canvas.width = 100
      canvas.height = 100
      const ctx = canvas.getContext("2d")
      if (ctx) {
        ctx.fillStyle = "#FF6B6B"
        ctx.fillRect(0, 0, 100, 100)

        canvas.toBlob(async (blob) => {
          if (blob) {
            const testFile = new File([blob], "test-image.png", { type: "image/png" })
            const analysis = await analyzeImageWithVision(testFile)

            console.log(`   Labels found: ${analysis.labels?.length || 0}`)
            console.log(`   Objects found: ${analysis.objects?.length || 0}`)
            console.log(`   Text detected: ${analysis.text ? "Yes" : "No"}`)

            if (analysis.labels && analysis.labels.length > 0) {
              console.log("   Top labels:")
              analysis.labels.slice(0, 3).forEach((label, i) => {
                console.log(`     ${i + 1}. ${label.description} (${(label.score * 100).toFixed(1)}%)`)
              })
            }
          }
        }, "image/png")
      }
    } else {
      console.log("   ⚠️  Cannot create test image in this environment")
    }
  } catch (error) {
    console.log(`   ❌ Sample analysis failed: ${error}`)
  }
  console.log()

  // Test 4: Performance Metrics
  console.log("4. Performance Recommendations:")
  console.log("   • Use high-quality images (min 640px) for better accuracy")
  console.log("   • Compress images to reduce API call time")
  console.log("   • Consider caching results for repeated images")
  console.log("   • Monitor API quotas and usage")
  console.log()

  console.log("🎯 Vision API Test Complete!")
}

// Run the tests
runVisionAPITests().catch(console.error)
