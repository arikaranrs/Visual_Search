import { batchAddProducts } from "@/lib/services/firebase-service"
import { addProductsToAlgolia, initializeAlgoliaIndex } from "@/lib/services/algolia-service"
import { config, type Product } from "@/lib/config"

const sampleProducts: Omit<Product, "id">[] = [
  {
    name: "Wireless Bluetooth Headphones",
    price: 79.99,
    image: "/wireless-bluetooth-headphones.jpg",
    category: "electronics",
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
    tags: ["wireless", "bluetooth", "headphones", "audio", "music"],
  },
  {
    name: "Organic Cotton T-Shirt",
    price: 24.99,
    image: "/organic-cotton-t-shirt.jpg",
    category: "clothing",
    description: "Comfortable organic cotton t-shirt available in multiple colors and sizes.",
    tags: ["organic", "cotton", "t-shirt", "clothing", "sustainable"],
  },
  {
    name: "Smart Home Security Camera",
    price: 149.99,
    image: "/smart-security-camera.jpg",
    category: "electronics",
    description: "WiFi-enabled security camera with night vision and mobile app control.",
    tags: ["smart", "security", "camera", "wifi", "surveillance"],
  },
  {
    name: "Yoga Mat Premium",
    price: 39.99,
    image: "/premium-yoga-mat.png",
    category: "sports",
    description: "Non-slip premium yoga mat with extra cushioning for comfortable practice.",
    tags: ["yoga", "mat", "fitness", "exercise", "wellness"],
  },
  {
    name: "Coffee Maker Deluxe",
    price: 199.99,
    image: "/deluxe-coffee-maker.jpg",
    category: "home",
    description: "Programmable coffee maker with built-in grinder and thermal carafe.",
    tags: ["coffee", "maker", "kitchen", "appliance", "brewing"],
  },
  {
    name: "Running Shoes Athletic",
    price: 89.99,
    image: "/athletic-running-shoes.jpg",
    category: "sports",
    description: "Lightweight running shoes with advanced cushioning and breathable mesh.",
    tags: ["running", "shoes", "athletic", "sports", "footwear"],
  },
  {
    name: "Smartphone Case Protective",
    price: 19.99,
    image: "/protective-smartphone-case.jpg",
    category: "electronics",
    description: "Durable protective case with shock absorption and wireless charging support.",
    tags: ["smartphone", "case", "protective", "wireless", "charging"],
  },
  {
    name: "Desk Lamp LED Adjustable",
    price: 45.99,
    image: "/adjustable-led-desk-lamp.jpg",
    category: "home",
    description: "Energy-efficient LED desk lamp with adjustable brightness and color temperature.",
    tags: ["desk", "lamp", "led", "adjustable", "lighting"],
  },
  {
    name: "Backpack Travel Waterproof",
    price: 69.99,
    image: "/waterproof-travel-backpack.jpg",
    category: "clothing",
    description: "Waterproof travel backpack with multiple compartments and laptop sleeve.",
    tags: ["backpack", "travel", "waterproof", "laptop", "storage"],
  },
  {
    name: "Bluetooth Speaker Portable",
    price: 59.99,
    image: "/portable-bluetooth-speaker.jpg",
    category: "electronics",
    description: "Compact portable speaker with 360-degree sound and 12-hour battery life.",
    tags: ["bluetooth", "speaker", "portable", "wireless", "audio"],
  },
]

async function seedDatabase() {
  try {
    console.log("[v0] Starting database seeding...")

    // Add products to Firebase
    console.log("[v0] Adding products to Firebase...")
    const firebaseIds = await batchAddProducts(sampleProducts)
    console.log(`[v0] Added ${firebaseIds.length} products to Firebase`)

    // Prepare products for Algolia (with Firebase IDs)
    const productsWithIds: Product[] = sampleProducts.map((product, index) => ({
      ...product,
      id: firebaseIds[index],
      objectID: firebaseIds[index], // Algolia requires objectID
    }))

    // Initialize and seed Algolia if configured
    if (config.features.useAlgolia && config.algolia.appId && config.algolia.apiKey) {
      console.log("[v0] Initializing Algolia index...")
      await initializeAlgoliaIndex()

      console.log("[v0] Adding products to Algolia...")
      await addProductsToAlgolia(productsWithIds)
      console.log(`[v0] Added ${productsWithIds.length} products to Algolia`)
    } else {
      console.log("[v0] Algolia not configured, skipping Algolia seeding")
    }

    console.log("[v0] Database seeding completed successfully!")
  } catch (error) {
    console.error("[v0] Database seeding failed:", error)
    throw error
  }
}

// Run the seeding if this script is executed directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log("[v0] Seeding completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("[v0] Seeding failed:", error)
      process.exit(1)
    })
}

export { seedDatabase, sampleProducts }
