import firebase_admin
from firebase_admin import credentials, firestore
import pickle
import faiss
import numpy as np
import requests
from backend.models.openclip.image_embedder import processImageEmbedding

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

docs = db.collection('products').stream()
embeddings, ids, id_map = [], [], {}

for i, doc in enumerate(docs):
    p = doc.to_dict()
    if not p.get('image_url'): continue
    try:
        img = requests.get(p['image_url']).content
        emb = processImageEmbedding(img)
        embeddings.append(emb)
        ids.append(doc.id)
        id_map[i] = doc.id
    except Exception as e:
        print(f"Failed {doc.id}: {e}")

if not embeddings: raise Exception("No products to index")

embeddings = np.array(embeddings).astype('float32')
index = faiss.IndexFlatIP(embeddings.shape[1])
index.add(embeddings)

faiss.write_index(index, "faiss_index.bin")
with open("id_map.pkl", "wb") as f:
    pickle.dump(id_map, f)

print(f"✅ Indexed {len(embeddings)} products")
