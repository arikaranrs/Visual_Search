import { testVisionAPI } from "@/lib/services/vision-service"
import { config, validateConfig } from "@/lib/config"

async function testAllAPIs() {
  console.log("🧪 Testing all API connections...")
  console.log("=".repeat(50))

  // Validate configuration first
  console.log("📋 Validating configuration...")
  validateConfig()
  console.log("")

  // Test Google Vision API
  console.log("🔍 Testing Google Vision API...")
  const visionResult = await testVisionAPI()
  if (visionResult.success) {
    console.log("✅ Google Vision API: Connected successfully")
    console.log(`   Auth Method: ${visionResult.details?.authMethod}`)
    console.log(`   Project ID: ${visionResult.details?.projectId}`)
  } else {
    console.log("❌ Google Vision API: Failed")
    console.log(`   Error: ${visionResult.error}`)
    if (visionResult.details) {
      console.log(`   Details: ${JSON.stringify(visionResult.details, null, 2)}`)
    }
  }
  console.log("")

  // Test Algolia configuration
  console.log("🔎 Testing Algolia configuration...")
  if (config.algolia.appId && config.algolia.apiKey) {
    console.log("✅ Algolia: Configuration found")
    console.log(`   App ID: ${config.algolia.appId}`)
    console.log(`   Index: ${config.algolia.indexName}`)
  } else {
    console.log("❌ Algolia: Missing configuration")
  }
  console.log("")

  // Test Firebase configuration
  console.log("🔥 Testing Firebase configuration...")
  if (config.firebase.public.apiKey && config.firebase.projectId) {
    console.log("✅ Firebase: Configuration found")
    console.log(`   Project ID: ${config.firebase.public.projectId}`)
    console.log(`   Auth Domain: ${config.firebase.public.authDomain}`)
  } else {
    console.log("❌ Firebase: Missing configuration")
  }
  console.log("")

  // Feature flags status
  console.log("🚩 Feature flags status:")
  console.log(`   Vision API: ${config.features.useVisionApi ? "✅ Enabled" : "❌ Disabled"}`)
  console.log(`   Algolia Search: ${config.features.useAlgolia ? "✅ Enabled" : "❌ Disabled"}`)
  console.log(`   Semantic Search: ${config.features.useSemanticSearch ? "✅ Enabled" : "❌ Disabled"}`)
  console.log("")

  console.log("🎉 API testing completed!")
}

// Run the test
testAllAPIs().catch(console.error)
