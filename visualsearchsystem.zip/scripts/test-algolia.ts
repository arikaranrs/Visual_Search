import { config, validateConfig } from "../lib/config"
import algoliasearch from "algoliasearch"

async function testAlgoliaConnection() {
  try {
    console.log("[v0] Testing Algolia connection...")

    validateConfig()

    const client = algoliasearch(config.algolia.appId, config.algolia.adminApiKey)
    const index = client.initIndex("products")

    // Test connection
    const stats = await index.getSettings()
    console.log("[v0] ✅ Algolia connection successful")
    console.log("[v0] Index settings:", stats)

    // Test search
    const searchResults = await index.search("test")
    console.log(`[v0] ✅ Search test successful - ${searchResults.hits.length} results`)
  } catch (error) {
    console.error("[v0] ❌ Algolia connection failed:", error)
    process.exit(1)
  }
}

testAlgoliaConnection()
