import { testFirebaseConnection } from "@/lib/services/firebase-service"
import { testAlgoliaConnection } from "@/lib/services/algolia-service"
import { testVisionAPI } from "@/lib/services/vision-service"
import { config } from "@/lib/config"

interface TestResult {
  service: string
  success: boolean
  error?: string
  details?: any
}

async function testAllAPIs(): Promise<TestResult[]> {
  const results: TestResult[] = []

  console.log("[v0] Starting API connectivity tests...")
  console.log("[v0] Feature flags:", {
    useAlgolia: config.features.useAlgolia,
    useVisionApi: config.features.useVisionApi,
    useSemanticSearch: config.features.useSemanticSearch,
  })

  // Test Firebase
  console.log("[v0] Testing Firebase connection...")
  try {
    const firebaseResult = await testFirebaseConnection()
    results.push({
      service: "Firebase",
      success: firebaseResult.success,
      error: firebaseResult.error,
    })
    console.log(`[v0] Firebase test: ${firebaseResult.success ? "PASS" : "FAIL"}`)
    if (firebaseResult.error) {
      console.log(`[v0] Firebase error details: ${firebaseResult.error}`)
    }
  } catch (error) {
    results.push({
      service: "Firebase",
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    })
    console.log("[v0] Firebase test: FAIL")
  }

  // Test Algolia - Always test if API key is available, regardless of feature flag
  if (process.env.ALGOLIA_APP_ID && process.env.ALGOLIA_API_KEY) {
    console.log("[v0] Testing Algolia connection...")
    try {
      const algoliaResult = await testAlgoliaConnection()
      results.push({
        service: "Algolia",
        success: algoliaResult.success,
        error: algoliaResult.error,
      })
      console.log(`[v0] Algolia test: ${algoliaResult.success ? "PASS" : "FAIL"}`)
    } catch (error) {
      results.push({
        service: "Algolia",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      })
      console.log("[v0] Algolia test: FAIL")
    }
  } else {
    results.push({
      service: "Algolia",
      success: false,
      error: "API keys not configured",
    })
    console.log("[v0] Algolia test: SKIPPED (API keys missing)")
  }

  // Test Google Vision API - Always test if API key is available
  if (process.env.GOOGLE_VISION_API_KEY) {
    console.log("[v0] Testing Google Vision API...")
    try {
      const visionResult = await testVisionAPI()
      results.push({
        service: "Google Vision",
        success: visionResult.success,
        error: visionResult.error,
      })
      console.log(`[v0] Google Vision test: ${visionResult.success ? "PASS" : "FAIL"}`)
    } catch (error) {
      results.push({
        service: "Google Vision",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      })
      console.log("[v0] Google Vision test: FAIL")
    }
  } else {
    results.push({
      service: "Google Vision",
      success: false,
      error: "API key not configured",
    })
    console.log("[v0] Google Vision test: SKIPPED (API key missing)")
  }

  return results
}

async function testAPIEndpoints(): Promise<void> {
  console.log("[v0] Testing API endpoints...")
  console.log("[v0] Note: These tests require the development server to be running")

  const baseUrl = config.app.apiUrl

  // Test health endpoint
  try {
    const healthResponse = await fetch(`${baseUrl}/api/health`)
    const healthData = await healthResponse.json()
    console.log("[v0] Health endpoint:", healthResponse.ok ? "PASS" : "FAIL")
    if (healthResponse.ok) {
      console.log("[v0] Health data:", JSON.stringify(healthData, null, 2))
    }
  } catch (error) {
    console.log("[v0] Health endpoint: FAIL - Development server not running")
    console.log("[v0] To test endpoints, run 'npm run dev' in another terminal")
  }

  // Test text search endpoint
  try {
    const textResponse = await fetch(`${baseUrl}/api/text`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: "test" }),
    })
    const textData = await textResponse.json()
    console.log("[v0] Text search endpoint:", textResponse.ok ? "PASS" : "FAIL")
    if (textResponse.ok) {
      console.log("[v0] Text search results:", textData.products?.length || 0, "products")
    }
  } catch (error) {
    console.log("[v0] Text search endpoint: FAIL - Development server not running")
  }

  // Test voice search endpoint
  try {
    const voiceResponse = await fetch(`${baseUrl}/api/voice`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript: "test" }),
    })
    const voiceData = await voiceResponse.json()
    console.log("[v0] Voice search endpoint:", voiceResponse.ok ? "PASS" : "FAIL")
    if (voiceResponse.ok) {
      console.log("[v0] Voice search results:", voiceData.products?.length || 0, "products")
    }
  } catch (error) {
    console.log("[v0] Voice search endpoint: FAIL - Development server not running")
  }
}

async function runAllTests(): Promise<void> {
  try {
    console.log("[v0] =================================")
    console.log("[v0] Visual Search System API Tests")
    console.log("[v0] =================================")

    console.log("[v0] Environment Variables Check:")
    console.log("[v0] USE_ALGOLIA:", process.env.USE_ALGOLIA)
    console.log("[v0] USE_VISION_API:", process.env.USE_VISION_API)
    console.log("[v0] ALGOLIA_APP_ID:", process.env.ALGOLIA_APP_ID ? "✅ Set" : "❌ Missing")
    console.log("[v0] GOOGLE_VISION_API_KEY:", process.env.GOOGLE_VISION_API_KEY ? "✅ Set" : "❌ Missing")
    console.log(
      "[v0] NEXT_PUBLIC_FIREBASE_API_KEY:",
      process.env.NEXT_PUBLIC_FIREBASE_API_KEY ? "✅ Set" : "❌ Missing",
    )

    // Test external API connections
    const apiResults = await testAllAPIs()

    // Test internal API endpoints
    await testAPIEndpoints()

    // Summary
    console.log("[v0] =================================")
    console.log("[v0] Test Summary:")
    console.log("[v0] =================================")

    apiResults.forEach((result) => {
      console.log(`[v0] ${result.service}: ${result.success ? "✅ PASS" : "❌ FAIL"}`)
      if (result.error) {
        console.log(`[v0]   Error: ${result.error}`)
      }
    })

    const passCount = apiResults.filter((r) => r.success).length
    const totalCount = apiResults.length

    console.log(`[v0] Overall: ${passCount}/${totalCount} services passing`)

    if (passCount === totalCount) {
      console.log("[v0] 🎉 All tests passed! System is ready.")
    } else {
      console.log("[v0] ⚠️  Some tests failed. Check configuration and API keys.")
    }
  } catch (error) {
    console.error("[v0] Test execution failed:", error)
    throw error
  }
}

// Run tests if this script is executed directly
if (require.main === module) {
  runAllTests()
    .then(() => {
      console.log("[v0] Testing completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("[v0] Testing failed:", error)
      process.exit(1)
    })
}

export { testAllAPIs, testAPIEndpoints, runAllTests }
