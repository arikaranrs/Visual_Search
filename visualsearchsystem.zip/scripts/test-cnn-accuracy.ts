import { analyzeImageWithVision, extractSearchKeywords } from "@/lib/services/vision-service"

interface AccuracyTestResult {
  imageName: string
  expectedKeywords: string[]
  detectedKeywords: string[]
  accuracy: number
  confidence: number
  processingTime: number
}

const testImages = [
  {
    name: "red_sneakers.jpg",
    expectedKeywords: ["shoe", "sneaker", "red", "footwear", "athletic"],
    description: "Red athletic sneakers",
  },
  {
    name: "blue_jeans.jpg",
    expectedKeywords: ["jeans", "denim", "blue", "pants", "clothing"],
    description: "Blue denim jeans",
  },
  {
    name: "black_watch.jpg",
    expectedKeywords: ["watch", "timepiece", "black", "accessory", "wrist"],
    description: "Black wrist watch",
  },
]

function calculateAccuracy(expected: string[], detected: string[]): number {
  if (expected.length === 0) return 0

  const matches = expected.filter((keyword) =>
    detected.some(
      (detected) =>
        detected.toLowerCase().includes(keyword.toLowerCase()) ||
        keyword.toLowerCase().includes(detected.toLowerCase()),
    ),
  )

  return (matches.length / expected.length) * 100
}

function calculateConfidence(analysis: any): number {
  if (!analysis.labels || analysis.labels.length === 0) return 0

  const avgScore = analysis.labels.reduce((sum: number, label: any) => sum + label.score, 0) / analysis.labels.length
  return avgScore * 100
}

async function createTestImageFile(imageName: string): Promise<File> {
  // Create a simple colored rectangle as test image
  const canvas = document.createElement("canvas")
  canvas.width = 200
  canvas.height = 200
  const ctx = canvas.getContext("2d")!

  // Set background color based on image name
  if (imageName.includes("red")) {
    ctx.fillStyle = "#FF0000"
  } else if (imageName.includes("blue")) {
    ctx.fillStyle = "#0000FF"
  } else if (imageName.includes("black")) {
    ctx.fillStyle = "#000000"
  } else {
    ctx.fillStyle = "#CCCCCC"
  }

  ctx.fillRect(0, 0, 200, 200)

  // Add some text to simulate product features
  ctx.fillStyle = "white"
  ctx.font = "16px Arial"
  ctx.fillText(imageName.split("_")[1].split(".")[0], 50, 100)

  return new Promise((resolve) => {
    canvas.toBlob(
      (blob) => {
        resolve(new File([blob!], imageName, { type: "image/jpeg" }))
      },
      "image/jpeg",
      0.8,
    )
  })
}

export async function testCNNAccuracy(): Promise<void> {
  console.log("🧠 Testing CNN Image Recognition Accuracy")
  console.log("=".repeat(50))

  const results: AccuracyTestResult[] = []

  for (const testImage of testImages) {
    console.log(`\n🔍 Testing: ${testImage.description}`)

    const startTime = Date.now()

    try {
      // Create test image file
      const imageFile = await createTestImageFile(testImage.name)
      console.log(`   Created test image: ${imageFile.name} (${imageFile.size} bytes)`)

      // Analyze with Vision API
      const analysis = await analyzeImageWithVision(imageFile)
      const detectedKeywords = extractSearchKeywords(analysis)

      const processingTime = Date.now() - startTime
      const accuracy = calculateAccuracy(testImage.expectedKeywords, detectedKeywords)
      const confidence = calculateConfidence(analysis)

      console.log(`   Expected: ${testImage.expectedKeywords.join(", ")}`)
      console.log(`   Detected: ${detectedKeywords.join(", ")}`)
      console.log(`   Accuracy: ${accuracy.toFixed(1)}%`)
      console.log(`   Confidence: ${confidence.toFixed(1)}%`)
      console.log(`   Processing Time: ${processingTime}ms`)

      results.push({
        imageName: testImage.name,
        expectedKeywords: testImage.expectedKeywords,
        detectedKeywords,
        accuracy,
        confidence,
        processingTime,
      })

      if (accuracy >= 60) {
        console.log("   ✅ Good accuracy")
      } else if (accuracy >= 40) {
        console.log("   ⚠️  Moderate accuracy")
      } else {
        console.log("   ❌ Low accuracy")
      }
    } catch (error) {
      console.log(`   ❌ Error: ${error}`)
      results.push({
        imageName: testImage.name,
        expectedKeywords: testImage.expectedKeywords,
        detectedKeywords: [],
        accuracy: 0,
        confidence: 0,
        processingTime: Date.now() - startTime,
      })
    }
  }

  // Overall results
  console.log("\n📊 Overall CNN Accuracy Results")
  console.log("=".repeat(50))

  const avgAccuracy = results.reduce((sum, r) => sum + r.accuracy, 0) / results.length
  const avgConfidence = results.reduce((sum, r) => sum + r.confidence, 0) / results.length
  const avgProcessingTime = results.reduce((sum, r) => sum + r.processingTime, 0) / results.length

  console.log(`Average Accuracy: ${avgAccuracy.toFixed(1)}%`)
  console.log(`Average Confidence: ${avgConfidence.toFixed(1)}%`)
  console.log(`Average Processing Time: ${avgProcessingTime.toFixed(0)}ms`)

  if (avgAccuracy >= 70) {
    console.log("\n🎉 Excellent CNN performance! Ready for production.")
  } else if (avgAccuracy >= 50) {
    console.log("\n✅ Good CNN performance. Consider fine-tuning for better results.")
  } else {
    console.log("\n⚠️  CNN performance needs improvement. Check model configuration.")
  }

  // Recommendations
  console.log("\n💡 Performance Recommendations:")
  if (avgProcessingTime > 3000) {
    console.log("   • Consider optimizing image preprocessing for faster results")
  }
  if (avgAccuracy < 60) {
    console.log("   • Consider training with more product-specific data")
    console.log("   • Adjust confidence thresholds in vision service")
  }
  if (avgConfidence < 50) {
    console.log("   • Improve image quality preprocessing")
    console.log("   • Consider ensemble methods for better confidence")
  }
}

// Run accuracy test if this script is executed directly
if (require.main === module) {
  testCNNAccuracy().catch(console.error)
}
