import { runAllTests } from "./test-all-connections"
import { testCNNAccuracy } from "./test-cnn-accuracy"

async function main() {
  console.log("🚀 Starting Complete System Test Suite")
  console.log("=".repeat(60))

  try {
    // Run all API connection tests
    await runAllTests()

    console.log("\n" + "=".repeat(60))

    // Run CNN accuracy tests
    await testCNNAccuracy()

    console.log("\n🎯 All tests completed successfully!")
  } catch (error) {
    console.error("❌ Test suite failed:", error)
    process.exit(1)
  }
}

main()
