import { config, validateConfig } from "@/lib/config"
import { runAllTests } from "./test-all-connections"
import { seedDatabase } from "./seed-database"

interface SetupStep {
  name: string
  description: string
  execute: () => Promise<boolean>
}

async function validateEnvironment(): Promise<boolean> {
  console.log("🔧 Validating Environment Configuration...")

  try {
    validateConfig()
    console.log("✅ Environment configuration is valid")
    return true
  } catch (error) {
    console.log("❌ Environment configuration failed")
    console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    return false
  }
}

async function installDependencies(): Promise<boolean> {
  console.log("📦 Checking Dependencies...")

  try {
    // Check if critical dependencies are available
    const criticalDeps = ["@google-cloud/vision", "algoliasearch", "firebase-admin", "tensorflow", "sharp"]

    for (const dep of criticalDeps) {
      try {
        require.resolve(dep)
        console.log(`   ✅ ${dep}`)
      } catch {
        console.log(`   ❌ ${dep} - Missing`)
        return false
      }
    }

    console.log("✅ All critical dependencies are installed")
    return true
  } catch (error) {
    console.log("❌ Dependency check failed")
    console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    return false
  }
}

async function testConnections(): Promise<boolean> {
  console.log("🔗 Testing API Connections...")

  try {
    await runAllTests()
    console.log("✅ API connection tests completed")
    return true
  } catch (error) {
    console.log("❌ API connection tests failed")
    console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    return false
  }
}

async function initializeDatabase(): Promise<boolean> {
  console.log("🗄️ Initializing Database...")

  try {
    await seedDatabase()
    console.log("✅ Database initialization completed")
    return true
  } catch (error) {
    console.log("❌ Database initialization failed")
    console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    return false
  }
}

async function verifySetup(): Promise<boolean> {
  console.log("✅ Verifying Complete Setup...")

  try {
    // Verify all systems are working
    const checks = [
      { name: "Environment Variables", check: () => !!config.googleVision.projectId },
      { name: "Google Vision API", check: () => !!config.googleVision.apiKey },
      { name: "Algolia Configuration", check: () => !!config.algolia.appId },
      { name: "Firebase Configuration", check: () => !!config.firebase.public.projectId },
      { name: "Feature Flags", check: () => config.features.useVisionApi || config.features.useAlgolia },
    ]

    let allPassed = true
    for (const check of checks) {
      const passed = check.check()
      console.log(`   ${passed ? "✅" : "❌"} ${check.name}`)
      if (!passed) allPassed = false
    }

    if (allPassed) {
      console.log("✅ All verification checks passed")
      return true
    } else {
      console.log("❌ Some verification checks failed")
      return false
    }
  } catch (error) {
    console.log("❌ Setup verification failed")
    console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    return false
  }
}

export async function setupProject(): Promise<void> {
  console.log("🚀 Starting Visual Search System Setup")
  console.log("=".repeat(60))

  const steps: SetupStep[] = [
    {
      name: "Environment Validation",
      description: "Validate environment variables and configuration",
      execute: validateEnvironment,
    },
    {
      name: "Dependency Check",
      description: "Verify all required dependencies are installed",
      execute: installDependencies,
    },
    {
      name: "API Connection Tests",
      description: "Test connections to Google Vision, Algolia, and Firebase",
      execute: testConnections,
    },
    {
      name: "Database Initialization",
      description: "Seed database with sample products and configure indexes",
      execute: initializeDatabase,
    },
    {
      name: "Setup Verification",
      description: "Verify complete system functionality",
      execute: verifySetup,
    },
  ]

  let completedSteps = 0
  let failedSteps = 0

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i]
    console.log(`\n📋 Step ${i + 1}/${steps.length}: ${step.name}`)
    console.log(`   ${step.description}`)
    console.log("-".repeat(40))

    try {
      const success = await step.execute()
      if (success) {
        completedSteps++
        console.log(`✅ Step ${i + 1} completed successfully`)
      } else {
        failedSteps++
        console.log(`❌ Step ${i + 1} failed`)
      }
    } catch (error) {
      failedSteps++
      console.log(`❌ Step ${i + 1} failed with exception`)
      console.log(`   Error: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  // Final summary
  console.log("\n" + "=".repeat(60))
  console.log("📊 Setup Summary")
  console.log("=".repeat(60))
  console.log(`✅ Completed Steps: ${completedSteps}/${steps.length}`)
  console.log(`❌ Failed Steps: ${failedSteps}/${steps.length}`)

  if (failedSteps === 0) {
    console.log("\n🎉 Setup completed successfully!")
    console.log("Your Visual Search System is ready for use.")
    console.log("\nNext steps:")
    console.log("1. Run 'npm run dev' to start the development server")
    console.log("2. Upload test images to verify search functionality")
    console.log("3. Check the admin dashboard for system status")
  } else if (completedSteps >= 3) {
    console.log("\n⚠️  Setup completed with some issues.")
    console.log("Core functionality should work, but some features may be limited.")
    console.log("\nRecommendations:")
    console.log("1. Review failed steps and fix configuration issues")
    console.log("2. Run 'npm run test:apis' to diagnose specific problems")
    console.log("3. Check environment variables in .env.local")
  } else {
    console.log("\n🚨 Setup failed with critical issues.")
    console.log("Please resolve the following before proceeding:")
    console.log("1. Check all environment variables are correctly set")
    console.log("2. Verify API keys and credentials are valid")
    console.log("3. Ensure all required dependencies are installed")
    console.log("4. Run 'npm audit fix --force' to resolve security issues")
  }

  console.log("=".repeat(60))
}

// Run setup if this script is executed directly
if (require.main === module) {
  setupProject().catch(console.error)
}
