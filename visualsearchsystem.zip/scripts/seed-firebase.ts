import { initializeApp } from "firebase/app"
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore"

// Firebase configuration - using environment variables
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

const app = initializeApp(firebaseConfig)
const db = getFirestore(app)

// Sample product data for seeding
const sampleProducts = [
  {
    name: "wireless bluetooth headphones",
    category: "electronics",
    description: "high-quality wireless bluetooth headphones with noise cancellation",
    price: 199.99,
    image: "/wireless-bluetooth-headphones.jpg",
  },
  {
    name: "smartphone case",
    category: "electronics",
    description: "protective smartphone case with drop protection",
    price: 29.99,
    image: "/stylish-smartphone-case.png",
  },
  {
    name: "cotton t-shirt",
    category: "clothing",
    description: "comfortable cotton t-shirt in various colors",
    price: 24.99,
    image: "/cotton-t-shirt.jpg",
  },
  {
    name: "running shoes",
    category: "sports",
    description: "lightweight running shoes for daily training",
    price: 129.99,
    image: "/running-shoes-on-track.png",
  },
  {
    name: "coffee maker",
    category: "home",
    description: "automatic drip coffee maker with programmable timer",
    price: 89.99,
    image: "/modern-coffee-maker.png",
  },
  {
    name: "laptop backpack",
    category: "electronics",
    description: "durable laptop backpack with multiple compartments",
    price: 59.99,
    image: "/laptop-backpack.png",
  },
  {
    name: "yoga mat",
    category: "sports",
    description: "non-slip yoga mat for exercise and meditation",
    price: 39.99,
    image: "/rolled-yoga-mat.png",
  },
  {
    name: "desk lamp",
    category: "home",
    description: "adjustable led desk lamp with touch controls",
    price: 49.99,
    image: "/modern-desk-lamp.png",
  },
  {
    name: "winter jacket",
    category: "clothing",
    description: "warm winter jacket with waterproof material",
    price: 159.99,
    image: "/winter-jacket.png",
  },
  {
    name: "gaming mouse",
    category: "electronics",
    description: "high-precision gaming mouse with rgb lighting",
    price: 79.99,
    image: "/gaming-mouse.png",
  },
  {
    name: "water bottle",
    category: "sports",
    description: "stainless steel water bottle with insulation",
    price: 19.99,
    image: "/reusable-water-bottle.png",
  },
  {
    name: "throw pillow",
    category: "home",
    description: "decorative throw pillow for sofa and bed",
    price: 14.99,
    image: "/decorative-throw-pillows.png",
  },
  {
    name: "denim jeans",
    category: "clothing",
    description: "classic denim jeans in regular fit",
    price: 69.99,
    image: "/denim-jeans.png",
  },
  {
    name: "wireless charger",
    category: "electronics",
    description: "fast wireless charging pad for smartphones",
    price: 34.99,
    image: "/wireless-charger.png",
  },
  {
    name: "tennis racket",
    category: "sports",
    description: "professional tennis racket for intermediate players",
    price: 149.99,
    image: "/tennis-racket.png",
  },
  {
    name: "kitchen knife set",
    category: "home",
    description: "professional kitchen knife set with wooden block",
    price: 99.99,
    image: "/kitchen-knife-set.jpg",
  },
  {
    name: "sneakers",
    category: "clothing",
    description: "casual sneakers for everyday wear",
    price: 89.99,
    image: "/diverse-sneaker-collection.png",
  },
  {
    name: "tablet stand",
    category: "electronics",
    description: "adjustable tablet stand for desk and bed",
    price: 25.99,
    image: "/minimalist-wooden-tablet-stand.png",
  },
  {
    name: "resistance bands",
    category: "sports",
    description: "set of resistance bands for home workouts",
    price: 29.99,
    image: "/resistance-bands-exercise.png",
  },
  {
    name: "candle set",
    category: "home",
    description: "scented candle set for relaxation and ambiance",
    price: 34.99,
    image: "/candle-set.png",
  },
]

async function seedDatabase() {
  try {
    console.log("Starting database seeding...")

    // Check if products already exist
    const productsRef = collection(db, "products")
    const existingProducts = await getDocs(productsRef)

    if (existingProducts.size > 0) {
      console.log(`Database already has ${existingProducts.size} products. Skipping seeding.`)
      return
    }

    // Add sample products
    let addedCount = 0
    for (const product of sampleProducts) {
      try {
        await addDoc(productsRef, product)
        addedCount++
        console.log(`Added product: ${product.name}`)
      } catch (error) {
        console.error(`Failed to add product ${product.name}:`, error)
      }
    }

    console.log(`Successfully seeded database with ${addedCount} products!`)
  } catch (error) {
    console.error("Error seeding database:", error)
    throw error
  }
}

// Run the seeding function
seedDatabase()
  .then(() => {
    console.log("Database seeding completed!")
    process.exit(0)
  })
  .catch((error) => {
    console.error("Database seeding failed:", error)
    process.exit(1)
  })
