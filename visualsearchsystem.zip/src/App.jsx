// src/App.jsx
import React, { useState } from 'react';
import SearchBar from './components/SearchBar';
import ResultsGrid from './components/ResultsGrid';
import './App.css';

function App() {
  const [results, setResults] = useState([]);

  return (
    <div className="App">
      <header className="app-header">
        <h1>🛍️ Visual Product Search</h1>
        <p>Search by text, voice, camera, or image — all connected to real APIs</p>
      </header>
      <main className="app-main">
        <SearchBar onResults={setResults} />
        <ResultsGrid results={results} />
      </main>
    </div>
  );
}

export default App;
