// src/services/apiClient.js

const API_BASE = process.env.NODE_ENV === 'development'
  ? 'http://localhost:3001/api'
  : 'https://your-production-api.com/api';

// 🔥 All calls go to REAL backend — no fallback, no mock

export const searchByText = async (query) => {
  const res = await fetch(`${API_BASE}/text?q=${encodeURIComponent(query)}`);
  if (!res.ok) throw new Error(`Search failed: ${res.statusText}`);
  return res.json();
};

export const searchByVoice = async (transcript) => {
  const res = await fetch(`${API_BASE}/voice`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: transcript })
  });
  if (!res.ok) throw new Error(`Voice search failed: ${res.statusText}`);
  return res.json();
};

export const searchByImage = async (imageBlob) => {
  const res = await fetch(`${API_BASE}/image`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body: imageBlob
  });
  if (!res.ok) throw new Error(`Image search failed: ${res.statusText}`);
  return res.json();
};

export const fetchAutocomplete = async (query) => {
  const res = await fetch(`${API_BASE}/autocomplete?q=${encodeURIComponent(query)}`);
  if (!res.ok) throw new Error(`Autocomplete failed: ${res.statusText}`);
  return res.json();
};
