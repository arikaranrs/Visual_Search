// src/components/CameraCapture.jsx
import React, { useRef, useState } from 'react';
import './CameraCapture.css';

const CameraCapture = ({ onCapture }) => {
  const videoRef = useRef();
  const canvasRef = useRef();
  const [streaming, setStreaming] = useState(false);
  const [captured, setCaptured] = useState(false);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      setStreaming(true);
    } catch (err) {
      alert(`📷 Camera access denied: ${err.message}`);
    }
  };

  const captureImage = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    canvas.toBlob((blob) => {
      onCapture(blob);
      setCaptured(true);
    }, 'image/jpeg', 0.95);
  };

  return (
    <div className="camera-capture-section">
      {!streaming ? (
        <button onClick={startCamera} className="glow-button">
          📹 Open Camera
        </button>
      ) : (
        <>
          <video ref={videoRef} autoPlay playsInline className="live-preview" />
          <canvas ref={canvasRef} style={{ display: 'none' }} />
          <button
            onClick={captureImage}
            disabled={captured}
            className={`capture-btn ${captured ? 'captured' : ''}`}
          >
            {captured ? '✅ Done' : '📸 Take Photo'}
          </button>
        </>
      )}
    </div>
  );
};

export default CameraCapture;
