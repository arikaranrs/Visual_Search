import "./ResultsGrid.css"

const ResultsGrid = ({ results }) => {
  if (!results.length) return <div className="no-results">No products found.</div>

  const getConfidenceClass = (score) => {
    if (score >= 85) return "high-confidence"
    if (score >= 65) return "medium-confidence"
    return "low-confidence"
  }

  const handleImageError = (e, product) => {
    const img = e.target
    const fallbackAttempts = Number.parseInt(img.dataset.fallbackAttempts || "0")

    if (fallbackAttempts === 0) {
      // First fallback: try alternative image URL
      img.dataset.fallbackAttempts = "1"
      img.src = product.imageUrl || product.image_url || product.thumbnail
    } else if (fallbackAttempts === 1) {
      // Second fallback: try Firebase storage URL
      img.dataset.fallbackAttempts = "2"
      img.src = `https://firebasestorage.googleapis.com/v0/b/your-project/o/products%2F${product.id}.jpg?alt=media`
    } else {
      // Final fallback: placeholder with product info
      img.dataset.fallbackAttempts = "3"
      img.src = `https://via.placeholder.com/300x220/f3f4f6/9ca3af?text=${encodeURIComponent(
        product.name || "Product Image",
      )}`
    }
  }

  return (
    <div className="results-grid zoom-in">
      {results.map((product) => (
        <div key={product.id} className="product-card slide-up">
          <div className="product-image-container">
            <img
              src={product.image_url || product.image || product.imageUrl}
              alt={product.name}
              className="product-image"
              onError={(e) => handleImageError(e, product)}
              onLoad={(e) => {
                e.target.style.background = "none"
                e.target.classList.add("loaded")
              }}
            />
            <div className="image-loading-placeholder">Loading...</div>
          </div>

          <div className="product-info">
            <h3 className="product-name">{product.name}</h3>
            <p className="product-price">${product.price?.toFixed(2)}</p>

            {product.similarityScore && (
              <div className={`match-badge ${getConfidenceClass(product.similarityScore * 100)}`}>
                {product.similarityScore >= 0.8
                  ? "Excellent"
                  : product.similarityScore >= 0.6
                    ? "Good"
                    : product.similarityScore >= 0.4
                      ? "Fair"
                      : "Possible"}{" "}
                Match
                <span className="match-percentage">({(product.similarityScore * 100).toFixed(0)}%)</span>
              </div>
            )}

            {product.searchScore && !product.similarityScore && (
              <div className={`match-badge ${getConfidenceClass(product.searchScore * 100)}`}>
                {(product.searchScore * 100).toFixed(0)}% Match
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

export default ResultsGrid
