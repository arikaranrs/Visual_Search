// src/components/VoiceInput.jsx
import React from 'react';
import './VoiceInput.css';

const VoiceInput = ({ onTranscript }) => {
  const startListening = () => {
    if (!('SpeechRecognition' in window) && !('webkitSpeechRecognition' in window)) {
      alert('🎙️ Speech Recognition not supported in your browser.');
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      document.body.classList.add('listening');
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      onTranscript(transcript);
      document.body.classList.remove('listening');
    };

    recognition.onerror = (event) => {
      alert(`🎙️ Speech error: ${event.error}`);
      document.body.classList.remove('listening');
    };

    recognition.start();
  };

  return (
    <div className="voice-input-section">
      <button onClick={startListening} className="pulse-button">
        🎙️ Speak Now
      </button>
      <p className="hint">Tap and speak — works on all devices</p>
    </div>
  );
};

export default VoiceInput;
