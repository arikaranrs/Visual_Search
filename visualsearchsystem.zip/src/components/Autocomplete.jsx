// src/components/Autocomplete.jsx
import React from 'react';
import './Autocomplete.css';

const Autocomplete = ({ suggestions, onSelect }) => {
  if (!suggestions.length) return null;

  return (
    <ul className="autocomplete-dropdown slide-down">
      {suggestions.map((item, index) => (
        <li
          key={index}
          onClick={() => onSelect(item)}
          className="suggestion-item"
        >
          {item.name}
        </li>
      ))}
    </ul>
  );
};

export default Autocomplete;
