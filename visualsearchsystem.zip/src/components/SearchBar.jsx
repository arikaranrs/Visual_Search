// src/components/SearchBar.jsx
import React, { useState, useRef, useEffect } from 'react';
import './SearchBar.css';
import VoiceInput from './VoiceInput';
import CameraCapture from './CameraCapture';
import ImageUploader from './ImageUploader';
import Autocomplete from './Autocomplete';
import { searchByText, searchByVoice, searchByImage } from '../services/apiClient';

const SearchBar = ({ onResults }) => {
  const [query, setQuery] = useState('');
  const [showVoice, setShowVoice] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [showImage, setShowImage] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const inputRef = useRef();

  const handleSearch = async (type, payload) => {
    setLoading(true);
    try {
      let response;
      switch (type) {
        case 'text':
          response = await searchByText(payload);
          break;
        case 'voice':
          response = await searchByVoice(payload);
          break;
        case 'image':
          response = await searchByImage(payload);
          break;
        default:
          throw new Error('Invalid search type');
      }
      onResults(response.results);
    } catch (error) {
      alert(`Search failed: ${error.message}`);
      onResults([]);
    } finally {
      setLoading(false);
    }
  };

  const handleTextSearch = (e) => {
    e.preventDefault();
    if (query.trim()) handleSearch('text', query);
  };

  // Real-time autocomplete
  useEffect(() => {
    if (!query.trim()) return setSuggestions([]);
    const timer = setTimeout(async () => {
      try {
        const { hits } = await fetchAutocomplete(query);
        setSuggestions(hits);
      } catch (err) {
        console.warn("Autocomplete failed:", err.message);
        setSuggestions([]);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="search-bar-container glass-morphism">
      <form onSubmit={handleTextSearch} className="search-form">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by text, voice, or image..."
          className="search-input"
        />
        <button type="submit" disabled={loading} className="search-button">
          {loading ? '⏳' : '🔍'}
        </button>
      </form>

      <div className="input-toggle">
        <button
          onClick={() => {
            setShowVoice(!showVoice);
            setShowCamera(false);
            setShowImage(false);
          }}
          className={`toggle-btn ${showVoice ? 'active' : ''}`}
          aria-label="Voice Search"
        >
          🎙️
        </button>
        <button
          onClick={() => {
            setShowCamera(!showCamera);
            setShowVoice(false);
            setShowImage(false);
          }}
          className={`toggle-btn ${showCamera ? 'active' : ''}`}
          aria-label="Camera Search"
        >
          📷
        </button>
        <button
          onClick={() => {
            setShowImage(!showImage);
            setShowVoice(false);
            setShowCamera(false);
          }}
          className={`toggle-btn ${showImage ? 'active' : ''}`}
          aria-label="Image Upload"
        >
          🖼️
        </button>
      </div>

      {showVoice && <VoiceInput onTranscript={(text) => handleSearch('voice', text)} />}
      {showCamera && <CameraCapture onCapture={(blob) => handleSearch('image', blob)} />}
      {showImage && <ImageUploader onUpload={(file) => handleSearch('image', file)} />}

      {suggestions.length > 0 && (
        <Autocomplete
          suggestions={suggestions}
          onSelect={(item) => {
            setQuery(item.name);
            setSuggestions([]);
            inputRef.current?.focus();
          }}
        />
      )}
    </div>
  );
};

export default SearchBar;
