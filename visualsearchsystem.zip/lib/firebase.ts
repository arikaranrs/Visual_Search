import { initializeApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { config } from "./config"

const firebaseConfig = {
  apiKey: config.firebase.public.apiKey,
  authDomain: config.firebase.public.authDomain,
  projectId: config.firebase.public.projectId,
  storageBucket: config.firebase.public.storageBucket,
  messagingSenderId: config.firebase.public.messagingSenderId,
  appId: config.firebase.public.appId,
}

if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
  console.warn("[v0] Firebase configuration incomplete. Some features may not work.")
}

const app = initializeApp(firebaseConfig)

export const db = getFirestore(app)
export const storage = getStorage(app)
export const firebaseApp = app

export { firebaseConfig }
