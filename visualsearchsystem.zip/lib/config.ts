export const config = {
  // Google Vision API
  googleVision: {
    apiKey: process.env.GOOGLE_VISION_API_KEY,
    credentials: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    projectId: process.env.GOOGLE_CLOUD_PROJECT_ID || "vision-api-demo-472116",
  },

  // Algolia Search
  algolia: {
    appId: process.env.ALGOLIA_APP_ID!,
    apiKey: process.env.ALGOLIA_API_KEY!,
    searchApiKey: process.env.ALGOLIA_SEARCH_API_KEY!,
    writeApiKey: process.env.ALGOLIA_WRITE_API_KEY!,
    adminApiKey: process.env.ALGOLIA_ADMIN_API_KEY!,
    usageApiKey: process.env.ALGOLIA_USAGE_API_KEY!,
    monitoringApiKey: process.env.ALGOLIA_MONITORING_API_KEY!,
    indexName: process.env.ALGOLIA_INDEX_NAME || "products",
  },

  // Firebase Configuration
  firebase: {
    // Server-side config
    projectId: process.env.FIREBASE_PROJECT_ID,
    privateKeyId: process.env.FIREBASE_PRIVATE_KEY_ID,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    clientId: process.env.FIREBASE_CLIENT_ID,
    authUri: process.env.FIREBASE_AUTH_URI,
    tokenUri: process.env.FIREBASE_TOKEN_URI,
    authProviderX509CertUrl: process.env.FIREBASE_AUTH_PROVIDER_X509_CERT_URL,
    clientX509CertUrl: process.env.FIREBASE_CLIENT_X509_CERT_URL,

    // Client-side config
    public: {
      apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
      authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
      databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
      projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
      storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
      appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
      measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
    },
  },

  // Application settings
  app: {
    nodeEnv: process.env.NODE_ENV || "development",
    port: Number.parseInt(process.env.PORT || "3000"),
    backendPort: Number.parseInt(process.env.BACKEND_PORT || "3001"),
    apiUrl: process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000",
    backendApiUrl: process.env.BACKEND_API_URL || "http://localhost:3001",
  },

  // Feature flags
  features: {
    useSemanticSearch: process.env.USE_SEMANTIC_SEARCH === "true",
    useVisionApi: process.env.USE_VISION_API === "true",
    useAlgolia: process.env.USE_ALGOLIA === "true",
  },
}

// Validation helper
export function validateConfig() {
  const required = ["ALGOLIA_APP_ID", "ALGOLIA_API_KEY", "NEXT_PUBLIC_FIREBASE_API_KEY", "FIREBASE_PROJECT_ID"]

  // Google Vision API is optional but at least one method should be available
  const hasVisionAPI = !!(process.env.GOOGLE_VISION_API_KEY || process.env.GOOGLE_APPLICATION_CREDENTIALS)

  const missing = required.filter((key) => !process.env[key])

  if (missing.length > 0) {
    console.warn(`⚠️  Missing environment variables: ${missing.join(", ")}`)
    console.warn("Some features may not work properly.")
  }

  if (!hasVisionAPI) {
    console.warn(
      "⚠️  Google Vision API not configured (missing GOOGLE_VISION_API_KEY or GOOGLE_APPLICATION_CREDENTIALS)",
    )
    console.warn("Image search will work with limited functionality.")
  }

  console.log("✅ Configuration loaded successfully")
  console.log(
    `📊 Features enabled: Vision API: ${config.features.useVisionApi}, Algolia: ${config.features.useAlgolia}`,
  )
}

// Type definitions for better TypeScript support
export interface Product {
  id: string
  name: string
  price: number
  image: string
  category: string
  description: string
  tags?: string[]
  objectID?: string // For Algolia
}

export interface SearchResult {
  products: Product[]
  query: string
  searchType: "text" | "voice" | "image"
  totalResults?: number
  processingTime?: number
}

export interface VisionAnalysis {
  labels: Array<{
    description: string
    score: number
  }>
  text?: string
  objects?: Array<{
    name: string
    score: number
  }>
}
