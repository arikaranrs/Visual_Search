import algoliasearch from "algoliasearch"
import { config } from "@/lib/config"

// Initialize Algolia client
let searchClient: any = null

function getAlgoliaClient() {
  if (!searchClient && config.algolia.appId && config.algolia.apiKey) {
    searchClient = algoliasearch(config.algolia.appId, config.algolia.apiKey)
  }
  return searchClient
}

export interface AlgoliaProduct {
  objectID: string
  name: string
  description: string
  price: number
  category: string
  image: string
  tags?: string[]
  brand?: string
  availability?: boolean
}

export interface AlgoliaSearchResult {
  hits: AlgoliaProduct[]
  nbHits: number
  page: number
  nbPages: number
  hitsPerPage: number
  processingTimeMS: number
  query: string
}

export async function searchWithAlgolia(
  query: string,
  options: {
    hitsPerPage?: number
    page?: number
    filters?: string
  } = {},
): Promise<AlgoliaSearchResult> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized. Check your API credentials.")
    }

    const index = client.initIndex(config.algolia.indexName)

    const searchOptions = {
      hitsPerPage: options.hitsPerPage || 20,
      page: options.page || 0,
      filters: options.filters || "",
    }

    console.log("[v0] Algolia search query:", query, "options:", searchOptions)

    const result = await index.search(query, searchOptions)

    console.log("[v0] Algolia search result:", {
      nbHits: result.nbHits,
      processingTimeMS: result.processingTimeMS,
    })

    return {
      hits: result.hits as AlgoliaProduct[],
      nbHits: result.nbHits,
      page: result.page,
      nbPages: result.nbPages,
      hitsPerPage: result.hitsPerPage,
      processingTimeMS: result.processingTimeMS,
      query: result.query,
    }
  } catch (error) {
    console.error("[v0] Algolia search error:", error)
    throw new Error(`Algolia search failed: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

export async function indexProduct(product: AlgoliaProduct): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)
    await index.saveObject(product)
    console.log("[v0] Product indexed successfully:", product.objectID)
  } catch (error) {
    console.error("[v0] Error indexing product:", error)
    throw error
  }
}

export async function indexProducts(products: AlgoliaProduct[]): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)
    await index.saveObjects(products)
    console.log("[v0] Batch indexed", products.length, "products successfully")
  } catch (error) {
    console.error("[v0] Error batch indexing products:", error)
    throw error
  }
}

export async function deleteProduct(objectID: string): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)
    await index.deleteObject(objectID)
    console.log("[v0] Product deleted successfully:", objectID)
  } catch (error) {
    console.error("[v0] Error deleting product:", error)
    throw error
  }
}

export async function clearIndex(): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)
    await index.clearObjects()
    console.log("[v0] Index cleared successfully")
  } catch (error) {
    console.error("[v0] Error clearing index:", error)
    throw error
  }
}

export async function testAlgoliaConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      return { success: false, error: "Algolia client not initialized. Check your API credentials." }
    }

    const index = client.initIndex(config.algolia.indexName)

    // Test with a simple search
    await index.search("test", { hitsPerPage: 1 })

    console.log("[v0] Algolia connection test successful")
    return { success: true }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    console.error("[v0] Algolia connection test failed:", errorMessage)
    return { success: false, error: errorMessage }
  }
}

export async function getIndexStats(): Promise<{
  nbRecords: number
  dataSize: number
  fileSize: number
  lastBuildTimeS: number
}> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)
    const stats = await index.getStats()

    return {
      nbRecords: stats.nbRecords || 0,
      dataSize: stats.dataSize || 0,
      fileSize: stats.fileSize || 0,
      lastBuildTimeS: stats.lastBuildTimeS || 0,
    }
  } catch (error) {
    console.error("[v0] Error getting index stats:", error)
    throw error
  }
}

export async function initializeAlgoliaIndex(): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)

    // Configure index settings for better search experience
    await index.setSettings({
      searchableAttributes: ["name", "description", "category", "tags", "brand"],
      attributesForFaceting: ["category", "brand", "availability"],
      customRanking: ["desc(price)"],
      ranking: ["typo", "geo", "words", "filters", "proximity", "attribute", "exact", "custom"],
    })

    console.log("[v0] Algolia index initialized successfully")
  } catch (error) {
    console.error("[v0] Error initializing Algolia index:", error)
    throw error
  }
}

export async function addProductsToAlgolia(products: AlgoliaProduct[]): Promise<void> {
  try {
    const client = getAlgoliaClient()
    if (!client) {
      throw new Error("Algolia client not initialized")
    }

    const index = client.initIndex(config.algolia.indexName)

    // Ensure all products have objectID
    const productsWithObjectId = products.map((product) => ({
      ...product,
      objectID: product.objectID || product.id,
    }))

    await index.saveObjects(productsWithObjectId)
    console.log("[v0] Successfully added", productsWithObjectId.length, "products to Algolia")
  } catch (error) {
    console.error("[v0] Error adding products to Algolia:", error)
    throw error
  }
}
