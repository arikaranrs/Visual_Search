import { config, type VisionAnalysis } from "@/lib/config"

interface EnhancedVisionAnalysis extends VisionAnalysis {
  confidence: number
  productCategories: string[]
  brandSuggestions: string[]
  colorAnalysis: string[]
  materialAnalysis: string[]
}

export async function analyzeImageWithEnhancedCNN(imageFile: File): Promise<EnhancedVisionAnalysis> {
  try {
    // Convert image to multiple formats for better analysis
    const imageBuffer = await imageFile.arrayBuffer()
    const base64Image = Buffer.from(imageBuffer).toString("base64")

    const requestPayload = {
      requests: [
        {
          image: { content: base64Image },
          features: [
            { type: "LABEL_DETECTION", maxResults: 30 },
            { type: "OBJECT_LOCALIZATION", maxResults: 25 },
            { type: "WEB_DETECTION", maxResults: 20 },
            { type: "TEXT_DETECTION", maxResults: 10 },
            { type: "PRODUCT_SEARCH", maxResults: 15 }, // Enhanced for e-commerce
            { type: "IMAGE_PROPERTIES" }, // Color analysis
          ],
        },
      ],
    }

    const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${config.googleVision.apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestPayload),
    })

    if (!response.ok) {
      throw new Error(`Vision API failed: ${response.status}`)
    }

    const data = await response.json()
    const visionResponse = data.responses?.[0]

    const analysis: EnhancedVisionAnalysis = {
      labels: [],
      text: undefined,
      objects: [],
      confidence: 0,
      productCategories: [],
      brandSuggestions: [],
      colorAnalysis: [],
      materialAnalysis: [],
    }

    // Process labels with enhanced filtering
    if (visionResponse.labelAnnotations) {
      analysis.labels = visionResponse.labelAnnotations
        .filter((label) => label.score > 0.3) // Lower threshold for better recall
        .map((label) => ({
          description: label.description,
          score: label.score,
        }))
        .sort((a, b) => b.score - a.score)

      // Extract product categories
      analysis.productCategories = analysis.labels
        .filter((label) =>
          ["clothing", "shoe", "bag", "watch", "jewelry", "electronics", "furniture", "book"].some((cat) =>
            label.description.toLowerCase().includes(cat),
          ),
        )
        .map((label) => label.description)
        .slice(0, 5)
    }

    // Enhanced object detection
    if (visionResponse.localizedObjectAnnotations) {
      analysis.objects = visionResponse.localizedObjectAnnotations
        .filter((obj) => obj.score > 0.25) // Lower threshold
        .map((obj) => ({
          name: obj.name,
          score: obj.score,
        }))
        .sort((a, b) => b.score - a.score)
    }

    // Color analysis from image properties
    if (visionResponse.imagePropertiesAnnotation?.dominantColors?.colors) {
      analysis.colorAnalysis = visionResponse.imagePropertiesAnnotation.dominantColors.colors
        .slice(0, 3)
        .map((color) => {
          const { red, green, blue } = color.color
          return getColorName(red, green, blue)
        })
    }

    // Calculate overall confidence
    const allScores = [...analysis.labels.map((l) => l.score), ...analysis.objects.map((o) => o.score)]
    analysis.confidence = allScores.length > 0 ? allScores.reduce((sum, score) => sum + score, 0) / allScores.length : 0

    return analysis
  } catch (error) {
    console.error("[v0] Enhanced vision analysis failed:", error)
    return {
      labels: [],
      text: undefined,
      objects: [],
      confidence: 0,
      productCategories: [],
      brandSuggestions: [],
      colorAnalysis: [],
      materialAnalysis: [],
    }
  }
}

export function extractEnhancedSearchKeywords(analysis: EnhancedVisionAnalysis): string[] {
  const keywords: string[] = []
  const keywordScores: Map<string, number> = new Map()

  // High-weight product categories
  analysis.productCategories.forEach((category) => {
    keywordScores.set(category.toLowerCase(), 1.0)
  })

  // Color analysis with high weight
  analysis.colorAnalysis.forEach((color) => {
    keywordScores.set(color.toLowerCase(), 0.9)
  })

  // Enhanced label processing with semantic grouping
  analysis.labels.forEach((label) => {
    const keyword = label.description.toLowerCase()
    const semanticWeight = getSemanticWeight(keyword)
    keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + label.score * semanticWeight)
  })

  // Object detection with spatial awareness
  analysis.objects.forEach((obj) => {
    const keyword = obj.name.toLowerCase()
    keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + obj.score * 0.8)
  })

  // Return top keywords sorted by relevance
  return Array.from(keywordScores.entries())
    .sort(([, a], [, b]) => b - a)
    .map(([keyword]) => keyword)
    .slice(0, 8) // Top 8 most relevant keywords
}

function getColorName(red: number, green: number, blue: number): string {
  // Simple color name mapping
  if (red > 200 && green < 100 && blue < 100) return "red"
  if (green > 200 && red < 100 && blue < 100) return "green"
  if (blue > 200 && red < 100 && green < 100) return "blue"
  if (red > 200 && green > 200 && blue < 100) return "yellow"
  if (red > 200 && green < 100 && blue > 200) return "purple"
  if (red < 100 && green > 200 && blue > 200) return "cyan"
  if (red > 150 && green > 150 && blue > 150) return "white"
  if (red < 100 && green < 100 && blue < 100) return "black"
  return "multicolor"
}

function getSemanticWeight(keyword: string): number {
  // Higher weights for e-commerce relevant terms
  const highWeight = ["shoe", "shirt", "dress", "bag", "watch", "phone", "laptop", "book"]
  const mediumWeight = ["clothing", "accessory", "electronics", "furniture", "toy"]

  if (highWeight.some((hw) => keyword.includes(hw))) return 1.2
  if (mediumWeight.some((mw) => keyword.includes(mw))) return 1.0
  return 0.8
}
