import { db } from "@/lib/firebase"
import {
  collection,
  query,
  where,
  getDocs,
  limit,
  orderBy,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDoc,
} from "firebase/firestore"
import { config, type Product } from "@/lib/config"

interface SearchResult {
  products: Product[]
  searchMethod: string
  confidence: number
  totalResults: number
}

// Search products in Firestore
export async function searchFirestore(searchQuery: string, getDiverse = false): Promise<Product[]> {
  try {
    const productsRef = collection(db, "products")
    const allProducts: Product[] = []

    if (getDiverse) {
      // Get diverse products from different categories
      const categories = ["electronics", "clothing", "home", "books", "sports"]

      for (const category of categories) {
        try {
          const categoryQuery = query(productsRef, where("category", "==", category), limit(3))
          const querySnapshot = await getDocs(categoryQuery)

          querySnapshot.forEach((doc) => {
            allProducts.push({
              id: doc.id,
              ...doc.data(),
            } as Product)
          })
        } catch (error) {
          console.log(`[v0] Could not fetch from category ${category}:`, error)
        }
      }

      // If no category-specific results, fall back to general query
      if (allProducts.length === 0) {
        const fallbackQuery = query(productsRef, limit(12))
        const querySnapshot = await getDocs(fallbackQuery)

        querySnapshot.forEach((doc) => {
          allProducts.push({
            id: doc.id,
            ...doc.data(),
          } as Product)
        })
      }

      // Shuffle and limit results
      return allProducts.sort(() => Math.random() - 0.5).slice(0, 8)
    }

    // Regular search
    const searchTerm = searchQuery.toLowerCase()

    // Create multiple queries for different fields
    const queries = [
      query(productsRef, where("name", ">=", searchTerm), where("name", "<=", searchTerm + "\uf8ff"), limit(10)),
      query(
        productsRef,
        where("category", ">=", searchTerm),
        where("category", "<=", searchTerm + "\uf8ff"),
        limit(10),
      ),
      query(
        productsRef,
        where("description", ">=", searchTerm),
        where("description", "<=", searchTerm + "\uf8ff"),
        limit(10),
      ),
    ]

    // Execute all queries in parallel
    const queryResults = await Promise.all(
      queries.map(async (q) => {
        try {
          return await getDocs(q)
        } catch (error) {
          console.warn("[v0] Firebase query failed:", error)
          return null
        }
      }),
    )

    // Combine and deduplicate results
    const productMap = new Map<string, Product>()

    queryResults.forEach((querySnapshot) => {
      if (querySnapshot) {
        querySnapshot.forEach((doc) => {
          const data = doc.data()
          productMap.set(doc.id, {
            id: doc.id,
            ...data,
          } as Product)
        })
      }
    })

    const products = Array.from(productMap.values())
    console.log(`[v0] Firebase search found ${products.length} products`)

    return products
  } catch (error) {
    console.error("[v0] Firebase search error:", error)
    throw new Error(`Firebase search failed: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Add a new product to Firestore
export async function addProduct(product: Omit<Product, "id">): Promise<string> {
  try {
    const productsRef = collection(db, "products")
    const docRef = await addDoc(productsRef, {
      ...product,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    console.log("[v0] Added product to Firebase:", docRef.id)
    return docRef.id
  } catch (error) {
    console.error("[v0] Firebase add product error:", error)
    throw new Error(`Failed to add product: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Update a product in Firestore
export async function updateProduct(productId: string, updates: Partial<Product>): Promise<void> {
  try {
    const productRef = doc(db, "products", productId)
    await updateDoc(productRef, {
      ...updates,
      updatedAt: new Date(),
    })

    console.log("[v0] Updated product in Firebase:", productId)
  } catch (error) {
    console.error("[v0] Firebase update product error:", error)
    throw new Error(`Failed to update product: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Delete a product from Firestore
export async function deleteProduct(productId: string): Promise<void> {
  try {
    const productRef = doc(db, "products", productId)
    await deleteDoc(productRef)

    console.log("[v0] Deleted product from Firebase:", productId)
  } catch (error) {
    console.error("[v0] Firebase delete product error:", error)
    throw new Error(`Failed to delete product: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Get a single product by ID
export async function getProduct(productId: string): Promise<Product | null> {
  try {
    const productRef = doc(db, "products", productId)
    const docSnap = await getDoc(productRef)

    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data(),
      } as Product
    } else {
      return null
    }
  } catch (error) {
    console.error("[v0] Firebase get product error:", error)
    throw new Error(`Failed to get product: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Get all products with pagination
export async function getAllProducts(limitCount = 50, startAfter?: any): Promise<Product[]> {
  try {
    const productsRef = collection(db, "products")
    let q = query(productsRef, orderBy("createdAt", "desc"), limit(limitCount))

    if (startAfter) {
      q = query(productsRef, orderBy("createdAt", "desc"), startAfter, limit(limitCount))
    }

    const querySnapshot = await getDocs(q)
    const products: Product[] = []

    querySnapshot.forEach((doc) => {
      products.push({
        id: doc.id,
        ...doc.data(),
      } as Product)
    })

    console.log(`[v0] Retrieved ${products.length} products from Firebase`)
    return products
  } catch (error) {
    console.error("[v0] Firebase get all products error:", error)
    throw new Error(`Failed to get products: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Test Firebase connectivity
export async function testFirebaseConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    if (!config.firebase.public.projectId || !config.firebase.public.apiKey) {
      return { success: false, error: "Firebase credentials not configured" }
    }

    // Test by trying to read from products collection
    const productsRef = collection(db, "products")
    const testQuery = query(productsRef, limit(1))
    await getDocs(testQuery)

    return { success: true }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

// Batch operations for syncing with Algolia
export async function batchAddProducts(products: Omit<Product, "id">[]): Promise<string[]> {
  try {
    const productsRef = collection(db, "products")
    const addPromises = products.map((product) =>
      addDoc(productsRef, {
        ...product,
        createdAt: new Date(),
        updatedAt: new Date(),
      }),
    )

    const docRefs = await Promise.all(addPromises)
    const ids = docRefs.map((ref) => ref.id)

    console.log(`[v0] Batch added ${ids.length} products to Firebase`)
    return ids
  } catch (error) {
    console.error("[v0] Firebase batch add error:", error)
    throw new Error(`Failed to batch add products: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Enhanced search function for similar products only
export async function searchSimilarProducts(keywords: string[], minSimilarityScore = 0.4): Promise<SearchResult> {
  if (!keywords || keywords.length === 0) {
    return {
      products: [],
      searchMethod: "none",
      confidence: 0,
      totalResults: 0,
    }
  }

  try {
    let products: Product[] = []
    let searchMethod = "firebase"
    const confidence = 0

    // Create focused search query from keywords
    const searchQuery = keywords.slice(0, 5).join(" ") // Use top 5 keywords

    console.log(`[v0] Searching for similar products with query: "${searchQuery}"`)

    // Search Firebase with similarity filtering
    products = await searchFirestoreWithSimilarity(searchQuery, keywords)
    searchMethod = "firebase"

    const filteredProducts = products
      .map((product) => ({
        ...product,
        similarityScore: calculateProductSimilarity(product, keywords),
      }))
      .filter((product) => product.similarityScore >= minSimilarityScore)
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, 20) // Limit to top 20 most similar products

    console.log(`[v0] Found ${filteredProducts.length} similar products (filtered from ${products.length})`)

    return {
      products: filteredProducts,
      searchMethod,
      confidence:
        filteredProducts.length > 0
          ? filteredProducts.reduce((sum, p) => sum + p.similarityScore, 0) / filteredProducts.length
          : 0,
      totalResults: filteredProducts.length,
    }
  } catch (error) {
    console.error("[v0] Enhanced search failed:", error)
    return {
      products: [],
      searchMethod: "error",
      confidence: 0,
      totalResults: 0,
    }
  }
}

async function searchFirestoreWithSimilarity(searchQuery: string, keywords: string[]): Promise<Product[]> {
  const allProducts: Product[] = []

  // Search across multiple fields with keyword matching
  for (const keyword of keywords.slice(0, 3)) {
    // Use top 3 keywords
    try {
      const keywordProducts = await searchFirestore(keyword)
      allProducts.push(...keywordProducts)
    } catch (error) {
      console.warn(`[v0] Firebase search failed for keyword "${keyword}":`, error)
    }
  }

  // Remove duplicates
  const uniqueProducts = Array.from(new Map(allProducts.map((p) => [p.id, p])).values())

  return uniqueProducts
}

function calculateProductSimilarity(product: Product, keywords: string[]): number {
  const productText = [
    product.name || "",
    product.description || "",
    product.category || "",
    product.brand || "",
    ...(product.tags || []),
  ]
    .join(" ")
    .toLowerCase()

  let matchScore = 0
  const totalKeywords = keywords.length

  keywords.forEach((keyword) => {
    const keywordLower = keyword.toLowerCase()

    // Exact match gets highest score
    if (productText.includes(keywordLower)) {
      matchScore += 1.0
    }
    // Partial match gets medium score
    else if (productText.split(" ").some((word) => word.includes(keywordLower) || keywordLower.includes(word))) {
      matchScore += 0.6
    }
    // Semantic similarity gets lower score
    else if (hasSemanticSimilarity(productText, keywordLower)) {
      matchScore += 0.3
    }
  })

  return totalKeywords > 0 ? matchScore / totalKeywords : 0
}

function hasSemanticSimilarity(productText: string, keyword: string): boolean {
  // Simple semantic similarity mapping for e-commerce
  const semanticGroups = {
    shoe: ["sneaker", "boot", "sandal", "heel", "footwear"],
    shirt: ["blouse", "top", "tee", "polo", "dress shirt"],
    bag: ["purse", "handbag", "backpack", "tote", "clutch"],
    watch: ["timepiece", "clock", "smartwatch"],
    phone: ["mobile", "smartphone", "cell phone", "iphone", "android"],
  }

  for (const [mainTerm, synonyms] of Object.entries(semanticGroups)) {
    if (keyword.includes(mainTerm) && synonyms.some((syn) => productText.includes(syn))) {
      return true
    }
    if (synonyms.includes(keyword) && productText.includes(mainTerm)) {
      return true
    }
  }

  return false
}
