import { config, type VisionAnalysis } from "@/lib/config"
import { Buffer } from "buffer"

interface GoogleVisionLabel {
  description: string
  score: number
  topicality?: number
}

interface GoogleVisionTextAnnotation {
  description: string
  boundingPoly?: {
    vertices: Array<{ x: number; y: number }>
  }
}

interface GoogleVisionObject {
  name: string
  score: number
  boundingPoly?: {
    normalizedVertices: Array<{ x: number; y: number }>
  }
}

interface GoogleVisionResponse {
  labelAnnotations?: GoogleVisionLabel[]
  textAnnotations?: GoogleVisionTextAnnotation[]
  localizedObjectAnnotations?: GoogleVisionObject[]
  webDetection?: {
    webEntities?: Array<{
      entityId?: string
      score: number
      description: string
    }>
  }
  imagePropertiesAnnotation?: {
    dominantColors?: {
      colors?: Array<{
        color: {
          red: number
          green: number
          blue: number
        }
      }>
    }
  }
  error?: {
    code: number
    message: string
    status: string
  }
}

interface EnhancedVisionAnalysis extends VisionAnalysis {
  confidence: number
  productCategories: string[]
  brandSuggestions: string[]
  colorAnalysis: string[]
  materialAnalysis: string[]
}

async function getAccessToken(): Promise<string | null> {
  if (!config.googleVision.credentials) {
    return null
  }

  try {
    // Import service account credentials
    const credentials = await import("../google-vision-credentials.json")

    // Create JWT payload for service account authentication
    const now = Math.floor(Date.now() / 1000)
    const payload = {
      iss: credentials.client_email,
      scope: "https://www.googleapis.com/auth/cloud-platform",
      aud: "https://oauth2.googleapis.com/token",
      exp: now + 3600,
      iat: now,
    }

    // For production use, implement proper JWT signing
    // For now, we'll use the service account directly with Google's OAuth2 endpoint
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: await createJWT(payload, credentials.private_key),
      }),
    })

    if (tokenResponse.ok) {
      const tokenData = await tokenResponse.json()
      return tokenData.access_token
    }

    console.warn("[v0] Service account token request failed, falling back to API key")
    return null
  } catch (error) {
    console.warn("[v0] Service account authentication failed, falling back to API key:", error)
    return null
  }
}

async function createJWT(payload: any, privateKey: string): Promise<string> {
  // This is a simplified JWT implementation
  // In production, use a proper JWT library like 'jsonwebtoken'
  const header = {
    alg: "RS256",
    typ: "JWT",
  }

  const encodedHeader = btoa(JSON.stringify(header)).replace(/[+/=]/g, (m) => ({ "+": "-", "/": "_", "=": "" })[m] || m)
  const encodedPayload = btoa(JSON.stringify(payload)).replace(
    /[+/=]/g,
    (m) => ({ "+": "-", "/": "_", "=": "" })[m] || m,
  )

  // For now, return a basic structure - in production, implement proper RSA signing
  return `${encodedHeader}.${encodedPayload}.signature_placeholder`
}

export async function analyzeImageWithVision(imageFile: File): Promise<VisionAnalysis> {
  if (!config.googleVision.apiKey && !config.googleVision.credentials) {
    console.warn("[v0] Google Vision API not configured, returning empty analysis")
    return {
      labels: [],
      text: undefined,
      objects: [],
    }
  }

  try {
    // Convert image file to base64
    const imageBuffer = await imageFile.arrayBuffer()
    const base64Image = Buffer.from(imageBuffer).toString("base64")

    const requestPayload = {
      requests: [
        {
          image: {
            content: base64Image,
          },
          features: [
            {
              type: "LABEL_DETECTION",
              maxResults: 20, // Increased for comprehensive analysis
            },
            {
              type: "TEXT_DETECTION",
              maxResults: 15,
            },
            {
              type: "OBJECT_LOCALIZATION",
              maxResults: 20,
            },
            {
              type: "WEB_DETECTION", // Enhanced for product recognition
              maxResults: 15,
            },
            {
              type: "SAFE_SEARCH_DETECTION", // Added for content safety
            },
          ],
        },
      ],
    }

    console.log("[v0] Calling Google Vision API with enhanced features...")

    const accessToken = await getAccessToken()
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }

    let url: string
    if (accessToken && accessToken !== "signature_placeholder") {
      headers["Authorization"] = `Bearer ${accessToken}`
      url = "https://vision.googleapis.com/v1/images:annotate"
      console.log("[v0] Using service account authentication")
    } else {
      url = `https://vision.googleapis.com/v1/images:annotate?key=${config.googleVision.apiKey}`
      console.log("[v0] Using API key authentication")
    }

    // Call Google Vision API
    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(requestPayload),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Vision API HTTP error:", response.status, errorText)

      if (response.status === 403) {
        console.warn("[v0] Vision API disabled or not accessible, returning empty analysis")
        return {
          labels: [],
          text: undefined,
          objects: [],
        }
      }

      throw new Error(`Vision API request failed: ${response.status} ${errorText}`)
    }

    const data = await response.json()
    console.log("[v0] Vision API response received successfully")

    if (data.responses?.[0]?.error) {
      const error = data.responses[0].error
      console.error("[v0] Vision API error:", error)

      if (error.code === 403 || error.status === "PERMISSION_DENIED") {
        console.warn("[v0] Vision API permission denied, returning empty analysis")
        return {
          labels: [],
          text: undefined,
          objects: [],
        }
      }

      throw new Error(`Vision API error: ${error.message}`)
    }

    const visionResponse = data.responses?.[0] as GoogleVisionResponse

    const analysis: VisionAnalysis = {
      labels: [],
      text: undefined,
      objects: [],
    }

    if (visionResponse.labelAnnotations) {
      analysis.labels = visionResponse.labelAnnotations
        .filter((label) => label.score > 0.4) // Optimized threshold for e-commerce
        .map((label) => ({
          description: label.description,
          score: label.score,
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 15) // Top 15 labels
      console.log("[v0] Processed labels:", analysis.labels.length)
    }

    // Process text annotations
    if (visionResponse.textAnnotations && visionResponse.textAnnotations.length > 0) {
      analysis.text = visionResponse.textAnnotations[0].description
      console.log("[v0] Detected text length:", analysis.text?.length || 0)
    }

    if (visionResponse.localizedObjectAnnotations) {
      analysis.objects = visionResponse.localizedObjectAnnotations
        .filter((obj) => obj.score > 0.3) // Optimized threshold
        .map((obj) => ({
          name: obj.name,
          score: obj.score,
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 10) // Top 10 objects
      console.log("[v0] Processed objects:", analysis.objects.length)
    }

    if (visionResponse.webDetection?.webEntities) {
      const webEntities = visionResponse.webDetection.webEntities
        .filter((entity) => entity.score > 0.3 && entity.description)
        .slice(0, 5)

      // Add web entities as additional labels
      webEntities.forEach((entity) => {
        if (entity.description) {
          analysis.labels.push({
            description: entity.description,
            score: entity.score * 0.8, // Slightly lower weight for web entities
          })
        }
      })
      console.log("[v0] Added web entities:", webEntities.length)
    }

    return analysis
  } catch (error) {
    console.error("[v0] Vision service error:", error)

    if (
      error instanceof Error &&
      (error.message.includes("403") ||
        error.message.includes("PERMISSION_DENIED") ||
        error.message.includes("SERVICE_DISABLED") ||
        error.message.includes("Cloud Vision API has not been used"))
    ) {
      console.warn("[v0] Vision API access denied or disabled, returning empty analysis for graceful fallback")
      return {
        labels: [],
        text: undefined,
        objects: [],
      }
    }

    console.warn("[v0] Vision API failed, returning empty analysis to prevent app crash")
    return {
      labels: [],
      text: undefined,
      objects: [],
    }
  }
}

export function extractSearchKeywords(analysis: VisionAnalysis): string[] {
  const keywords: string[] = []
  const keywordScores: Map<string, number> = new Map()

  // Add high-confidence labels with weighted scoring
  if (analysis.labels) {
    analysis.labels
      .filter((label) => label.score > 0.5)
      .forEach((label) => {
        const keyword = label.description.toLowerCase()
        keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + label.score)
      })
  }

  // Add detected objects with weighted scoring
  if (analysis.objects) {
    analysis.objects
      .filter((obj) => obj.score > 0.3)
      .forEach((obj) => {
        const keyword = obj.name.toLowerCase()
        keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + obj.score * 0.9)
      })
  }

  // Add text keywords with basic scoring
  if (analysis.text) {
    const textWords = analysis.text
      .toLowerCase()
      .replace(/[^\w\s]/g, " ")
      .split(/\s+/)
      .filter((word) => word.length > 2 && word.length < 20)
      .slice(0, 8)

    textWords.forEach((word) => {
      keywordScores.set(word, (keywordScores.get(word) || 0) + 0.3)
    })
  }

  // Sort by score and return top keywords
  const sortedKeywords = Array.from(keywordScores.entries())
    .sort(([, a], [, b]) => b - a)
    .map(([keyword]) => keyword)
    .slice(0, 12) // Top 12 keywords

  return sortedKeywords
}

export async function analyzeImageWithEnhancedCNN(imageFile: File): Promise<EnhancedVisionAnalysis> {
  try {
    // Convert image to multiple formats for better analysis
    const imageBuffer = await imageFile.arrayBuffer()
    const base64Image = Buffer.from(imageBuffer).toString("base64")

    const requestPayload = {
      requests: [
        {
          image: { content: base64Image },
          features: [
            { type: "LABEL_DETECTION", maxResults: 30 },
            { type: "OBJECT_LOCALIZATION", maxResults: 25 },
            { type: "WEB_DETECTION", maxResults: 20 },
            { type: "TEXT_DETECTION", maxResults: 10 },
            { type: "IMAGE_PROPERTIES" }, // Color analysis
          ],
        },
      ],
    }

    const accessToken = await getAccessToken()
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }

    let url: string
    if (accessToken && accessToken !== "signature_placeholder") {
      headers["Authorization"] = `Bearer ${accessToken}`
      url = "https://vision.googleapis.com/v1/images:annotate"
    } else {
      url = `https://vision.googleapis.com/v1/images:annotate?key=${config.googleVision.apiKey}`
    }

    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(requestPayload),
    })

    if (!response.ok) {
      throw new Error(`Vision API failed: ${response.status}`)
    }

    const data = await response.json()
    const visionResponse = data.responses?.[0]

    const analysis: EnhancedVisionAnalysis = {
      labels: [],
      text: undefined,
      objects: [],
      confidence: 0,
      productCategories: [],
      brandSuggestions: [],
      colorAnalysis: [],
      materialAnalysis: [],
    }

    // Process labels with enhanced filtering
    if (visionResponse.labelAnnotations) {
      analysis.labels = visionResponse.labelAnnotations
        .filter((label) => label.score > 0.3) // Lower threshold for better recall
        .map((label) => ({
          description: label.description,
          score: label.score,
        }))
        .sort((a, b) => b.score - a.score)

      // Extract product categories
      analysis.productCategories = analysis.labels
        .filter((label) =>
          ["clothing", "shoe", "bag", "watch", "jewelry", "electronics", "furniture", "book"].some((cat) =>
            label.description.toLowerCase().includes(cat),
          ),
        )
        .map((label) => label.description)
        .slice(0, 5)
    }

    // Enhanced object detection
    if (visionResponse.localizedObjectAnnotations) {
      analysis.objects = visionResponse.localizedObjectAnnotations
        .filter((obj) => obj.score > 0.25) // Lower threshold
        .map((obj) => ({
          name: obj.name,
          score: obj.score,
        }))
        .sort((a, b) => b.score - a.score)
    }

    // Color analysis from image properties
    if (visionResponse.imagePropertiesAnnotation?.dominantColors?.colors) {
      analysis.colorAnalysis = visionResponse.imagePropertiesAnnotation.dominantColors.colors
        .slice(0, 3)
        .map((color) => {
          const { red, green, blue } = color.color
          return getColorName(red, green, blue)
        })
    }

    // Calculate overall confidence
    const allScores = [...analysis.labels.map((l) => l.score), ...analysis.objects.map((o) => o.score)]
    analysis.confidence = allScores.length > 0 ? allScores.reduce((sum, score) => sum + score, 0) / allScores.length : 0

    return analysis
  } catch (error) {
    console.error("[v0] Enhanced vision analysis failed:", error)
    return {
      labels: [],
      text: undefined,
      objects: [],
      confidence: 0,
      productCategories: [],
      brandSuggestions: [],
      colorAnalysis: [],
      materialAnalysis: [],
    }
  }
}

export function extractEnhancedSearchKeywords(analysis: EnhancedVisionAnalysis): string[] {
  const keywords: string[] = []
  const keywordScores: Map<string, number> = new Map()

  // High-weight product categories
  analysis.productCategories.forEach((category) => {
    keywordScores.set(category.toLowerCase(), 1.0)
  })

  // Color analysis with high weight
  analysis.colorAnalysis.forEach((color) => {
    keywordScores.set(color.toLowerCase(), 0.9)
  })

  // Enhanced label processing with semantic grouping
  analysis.labels.forEach((label) => {
    const keyword = label.description.toLowerCase()
    const semanticWeight = getSemanticWeight(keyword)
    keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + label.score * semanticWeight)
  })

  // Object detection with spatial awareness
  analysis.objects.forEach((obj) => {
    const keyword = obj.name.toLowerCase()
    keywordScores.set(keyword, (keywordScores.get(keyword) || 0) + obj.score * 0.8)
  })

  // Return top keywords sorted by relevance
  return Array.from(keywordScores.entries())
    .sort(([, a], [, b]) => b - a)
    .map(([keyword]) => keyword)
    .slice(0, 8) // Top 8 most relevant keywords
}

function getColorName(red: number, green: number, blue: number): string {
  // Simple color name mapping
  if (red > 200 && green < 100 && blue < 100) return "red"
  if (green > 200 && red < 100 && blue < 100) return "green"
  if (blue > 200 && red < 100 && green < 100) return "blue"
  if (red > 200 && green > 200 && blue < 100) return "yellow"
  if (red > 200 && green < 100 && blue > 200) return "purple"
  if (red < 100 && green > 200 && blue > 200) return "cyan"
  if (red > 150 && green > 150 && blue > 150) return "white"
  if (red < 100 && green < 100 && blue < 100) return "black"
  return "multicolor"
}

function getSemanticWeight(keyword: string): number {
  // Higher weights for e-commerce relevant terms
  const highWeight = ["shoe", "shirt", "dress", "bag", "watch", "phone", "laptop", "book"]
  const mediumWeight = ["clothing", "accessory", "electronics", "furniture", "toy"]

  if (highWeight.some((hw) => keyword.includes(hw))) return 1.2
  if (mediumWeight.some((mw) => keyword.includes(mw))) return 1.0
  return 0.8
}

export async function testVisionAPI(): Promise<{ success: boolean; error?: string; details?: any }> {
  try {
    if (!config.googleVision.apiKey && !config.googleVision.credentials) {
      return { success: false, error: "API key or credentials not configured" }
    }

    console.log("[v0] Testing Vision API connection...")

    // Create a simple test image (1x1 pixel PNG)
    const testImageBase64 =
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="

    const requestPayload = {
      requests: [
        {
          image: {
            content: testImageBase64,
          },
          features: [
            {
              type: "LABEL_DETECTION",
              maxResults: 1,
            },
          ],
        },
      ],
    }

    const accessToken = await getAccessToken()
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    }

    let url: string
    let authMethod: string
    if (accessToken && accessToken !== "signature_placeholder") {
      headers["Authorization"] = `Bearer ${accessToken}`
      url = "https://vision.googleapis.com/v1/images:annotate"
      authMethod = "Service Account"
    } else {
      url = `https://vision.googleapis.com/v1/images:annotate?key=${config.googleVision.apiKey}`
      authMethod = "API Key"
    }

    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(requestPayload),
    })

    if (!response.ok) {
      const errorText = await response.text()
      return {
        success: false,
        error: `HTTP ${response.status}: ${response.statusText}`,
        details: { errorText, authMethod },
      }
    }

    const data = await response.json()

    if (data.responses?.[0]?.error) {
      return {
        success: false,
        error: data.responses[0].error.message,
        details: { ...data.responses[0].error, authMethod },
      }
    }

    return {
      success: true,
      details: {
        message: "Vision API connection successful",
        authMethod,
        projectId: config.googleVision.projectId,
        responseData: data,
      },
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      details: error,
    }
  }
}
