import { searchFirestore } from "./firebase-service"
import { searchWithAlgolia } from "./algolia-service"
import { config, type Product } from "@/lib/config"

interface SearchResult {
  products: Product[]
  searchMethod: string
  confidence: number
  totalResults: number
}

export async function searchSimilarProducts(keywords: string[], minSimilarityScore = 0.4): Promise<SearchResult> {
  if (!keywords || keywords.length === 0) {
    return {
      products: [],
      searchMethod: "none",
      confidence: 0,
      totalResults: 0,
    }
  }

  try {
    let products: Product[] = []
    let searchMethod = "firebase"
    let confidence = 0

    // Create focused search query from keywords
    const searchQuery = keywords.slice(0, 5).join(" ") // Use top 5 keywords

    console.log(`[v0] Searching for similar products with query: "${searchQuery}"`)

    // Try Algolia first for better relevance scoring
    if (config.features.useAlgolia && config.algolia.appId && config.algolia.apiKey) {
      try {
        const algoliaResults = await searchWithAlgolia(searchQuery, {
          hitsPerPage: 50, // Get more results for filtering
          filters: "", // No pre-filters, we'll filter by similarity
        })

        products = algoliaResults.hits || []
        searchMethod = "algolia"

        // Calculate confidence based on Algolia's relevance scores
        if (products.length > 0) {
          confidence = products.reduce((sum, p) => sum + (p._highlightResult?.score || 0.5), 0) / products.length
        }
      } catch (algoliaError) {
        console.warn("[v0] Algolia search failed, falling back to Firebase:", algoliaError)
        products = await searchFirestoreWithSimilarity(searchQuery, keywords)
        searchMethod = "firebase"
      }
    } else {
      products = await searchFirestoreWithSimilarity(searchQuery, keywords)
      searchMethod = "firebase"
    }

    const filteredProducts = products
      .map((product) => ({
        ...product,
        similarityScore: calculateProductSimilarity(product, keywords),
      }))
      .filter((product) => product.similarityScore >= minSimilarityScore)
      .sort((a, b) => b.similarityScore - a.similarityScore)
      .slice(0, 20) // Limit to top 20 most similar products

    console.log(`[v0] Found ${filteredProducts.length} similar products (filtered from ${products.length})`)

    return {
      products: filteredProducts,
      searchMethod,
      confidence:
        filteredProducts.length > 0
          ? filteredProducts.reduce((sum, p) => sum + p.similarityScore, 0) / filteredProducts.length
          : 0,
      totalResults: filteredProducts.length,
    }
  } catch (error) {
    console.error("[v0] Enhanced search failed:", error)
    return {
      products: [],
      searchMethod: "error",
      confidence: 0,
      totalResults: 0,
    }
  }
}

async function searchFirestoreWithSimilarity(searchQuery: string, keywords: string[]): Promise<Product[]> {
  const allProducts: Product[] = []

  // Search across multiple fields with keyword matching
  for (const keyword of keywords.slice(0, 3)) {
    // Use top 3 keywords
    try {
      const keywordProducts = await searchFirestore(keyword)
      allProducts.push(...keywordProducts)
    } catch (error) {
      console.warn(`[v0] Firebase search failed for keyword "${keyword}":`, error)
    }
  }

  // Remove duplicates
  const uniqueProducts = Array.from(new Map(allProducts.map((p) => [p.id, p])).values())

  return uniqueProducts
}

function calculateProductSimilarity(product: Product, keywords: string[]): number {
  const productText = [
    product.name || "",
    product.description || "",
    product.category || "",
    product.brand || "",
    ...(product.tags || []),
  ]
    .join(" ")
    .toLowerCase()

  let matchScore = 0
  const totalKeywords = keywords.length

  keywords.forEach((keyword) => {
    const keywordLower = keyword.toLowerCase()

    // Exact match gets highest score
    if (productText.includes(keywordLower)) {
      matchScore += 1.0
    }
    // Partial match gets medium score
    else if (productText.split(" ").some((word) => word.includes(keywordLower) || keywordLower.includes(word))) {
      matchScore += 0.6
    }
    // Semantic similarity gets lower score
    else if (hasSemanticSimilarity(productText, keywordLower)) {
      matchScore += 0.3
    }
  })

  return totalKeywords > 0 ? matchScore / totalKeywords : 0
}

function hasSemanticSimilarity(productText: string, keyword: string): boolean {
  // Simple semantic similarity mapping for e-commerce
  const semanticGroups = {
    shoe: ["sneaker", "boot", "sandal", "heel", "footwear"],
    shirt: ["blouse", "top", "tee", "polo", "dress shirt"],
    bag: ["purse", "handbag", "backpack", "tote", "clutch"],
    watch: ["timepiece", "clock", "smartwatch"],
    phone: ["mobile", "smartphone", "cell phone", "iphone", "android"],
  }

  for (const [mainTerm, synonyms] of Object.entries(semanticGroups)) {
    if (keyword.includes(mainTerm) && synonyms.some((syn) => productText.includes(syn))) {
      return true
    }
    if (synonyms.includes(keyword) && productText.includes(mainTerm)) {
      return true
    }
  }

  return false
}
