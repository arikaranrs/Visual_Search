"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import { Search, Mic, Camera, Upload, X, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Product {
  id: string
  name: string
  price: number
  image: string
  category: string
  description: string
}

interface SearchResult {
  products: Product[]
  query: string
  searchType: "text" | "voice" | "image"
}

declare global {
  interface Window {
    webkitSpeechRecognition: any
    SpeechRecognition: any
  }
}

export default function VisualSearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [showCameraOptions, setShowCameraOptions] = useState(false)
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [showCamera, setShowCamera] = useState(false)

  const handleError = (message: string, error?: any) => {
    console.error("[v0] Error:", message, error)
    setError(message)
    setTimeout(() => setError(null), 5000) // Clear error after 5 seconds
  }

  // Text Search
  const handleTextSearch = async (query: string) => {
    if (!query.trim()) return

    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch("/api/text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Search failed")
      }

      const data = await response.json()
      setSearchResults({
        products: data.products || [],
        query,
        searchType: "text",
      })
    } catch (error) {
      handleError("Text search failed. Please try again.", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Voice Search
  const handleVoiceSearch = useCallback(() => {
    if (!(typeof window !== "undefined" && ("webkitSpeechRecognition" in window || "SpeechRecognition" in window))) {
      handleError("Speech recognition not supported in this browser")
      return
    }

    const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
      setError(null)
    }
    recognition.onend = () => setIsListening(false)

    recognition.onresult = async (event: any) => {
      const transcript = event.results[0][0].transcript
      setSearchQuery(transcript)

      setIsLoading(true)
      try {
        const response = await fetch("/api/voice", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ transcript }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Voice search failed")
        }

        const data = await response.json()
        setSearchResults({
          products: data.products || [],
          query: transcript,
          searchType: "voice",
        })
      } catch (error) {
        handleError("Voice search failed. Please try again.", error)
      } finally {
        setIsLoading(false)
      }
    }

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error)
      setIsListening(false)
      handleError("Speech recognition error. Please try again.")
    }

    recognition.start()
  }, [])

  // Image Upload
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setSelectedImage(file)
    const reader = new FileReader()
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string)
    }
    reader.readAsDataURL(file)
    setShowCameraOptions(false)
  }

  // Camera Capture
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })
      setStream(mediaStream)
      setShowCamera(true)
      setShowCameraOptions(false)

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
      }
    } catch (error) {
      console.error("Camera access error:", error)
      alert("Unable to access camera")
    }
  }

  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current) return

    const canvas = canvasRef.current
    const video = videoRef.current
    const context = canvas.getContext("2d")

    if (!context) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    context.drawImage(video, 0, 0)

    canvas.toBlob(
      (blob) => {
        if (blob) {
          const file = new File([blob], "camera-capture.jpg", { type: "image/jpeg" })
          setSelectedImage(file)
          setImagePreview(canvas.toDataURL())
          stopCamera()
        }
      },
      "image/jpeg",
      0.8,
    )
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setShowCamera(false)
  }

  // Image Search
  const handleImageSearch = async () => {
    if (!selectedImage) return

    setIsLoading(true)
    setError(null)
    try {
      const formData = new FormData()
      formData.append("image", selectedImage)

      const response = await fetch("/api/image", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Image search failed")
      }

      const data = await response.json()
      setSearchResults({
        products: data.products || [],
        query: "Image Search",
        searchType: "image",
      })
    } catch (error) {
      handleError("Image search failed. Please try again.", error)
    } finally {
      setIsLoading(false)
    }
  }

  const clearImage = () => {
    setSelectedImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-foreground">Visual Search E-commerce</h1>
          <p className="text-sm text-muted-foreground mt-1">Search products using text, voice, or images</p>
        </div>
      </header>

      {/* Error Display */}
      {error && (
        <div className="container mx-auto px-4 py-2">
          <div className="max-w-4xl mx-auto">
            <div className="bg-destructive/10 border border-destructive/20 text-destructive px-4 py-2 rounded-lg">
              {error}
            </div>
          </div>
        </div>
      )}

      {/* Main Search Interface */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <div className="flex items-center gap-2 p-2 border border-border rounded-lg bg-card shadow-sm">
                <Search className="w-5 h-5 text-muted-foreground ml-2" />
                <Input
                  type="text"
                  placeholder="Search for products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleTextSearch(searchQuery)}
                  className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
                />

                {/* Voice Search Button */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleVoiceSearch}
                  disabled={isListening || isLoading}
                  className="relative"
                  title="Voice Search"
                >
                  <Mic
                    className={`w-4 h-4 ${isListening ? "text-destructive animate-pulse" : "text-muted-foreground"}`}
                  />
                  {isListening && (
                    <div className="absolute inset-0 rounded-full border-2 border-destructive animate-ping" />
                  )}
                </Button>

                {/* Camera Button */}
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowCameraOptions(!showCameraOptions)}
                    className="relative"
                    title="Image Search"
                  >
                    <Camera className="w-4 h-4 text-muted-foreground" />
                  </Button>

                  {/* Camera Options Dropdown */}
                  {showCameraOptions && (
                    <div className="absolute right-0 top-full mt-2 w-48 bg-popover border border-border rounded-lg shadow-lg z-10">
                      <div className="p-2">
                        <Button variant="ghost" size="sm" onClick={startCamera} className="w-full justify-start mb-1">
                          <Camera className="w-4 h-4 mr-2" />
                          Capture with Camera
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full justify-start"
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Image
                        </Button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Search Button */}
                <Button
                  onClick={() => handleTextSearch(searchQuery)}
                  disabled={isLoading || !searchQuery.trim()}
                  size="sm"
                >
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Search"}
                </Button>
              </div>
            </div>

            {/* Image Preview */}
            {imagePreview && (
              <div className="mt-4 p-4 border border-border rounded-lg bg-card">
                <div className="flex items-start gap-4">
                  <div className="relative">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Selected for search"
                      className="w-32 h-32 object-cover rounded-lg"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={clearImage}
                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-2">Image ready for search</p>
                    <Button onClick={handleImageSearch} disabled={isLoading} size="sm">
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      Search by Image
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Camera Modal */}
          {showCamera && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-card p-6 rounded-lg max-w-md w-full mx-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Capture Image</h3>
                  <Button variant="ghost" size="sm" onClick={stopCamera}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <div className="relative mb-4">
                  <video ref={videoRef} autoPlay playsInline className="w-full rounded-lg" />
                  <canvas ref={canvasRef} className="hidden" />
                </div>
                <div className="flex gap-2">
                  <Button onClick={captureImage} className="flex-1">
                    <Camera className="w-4 h-4 mr-2" />
                    Capture
                  </Button>
                  <Button variant="outline" onClick={stopCamera}>
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Search Results */}
          {searchResults && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Search Results</h2>
                  <div className="text-sm text-muted-foreground">
                    {searchResults.products.length} results for "{searchResults.query}"
                    <Badge variant="secondary" className="ml-2">
                      {searchResults.searchType}
                    </Badge>
                  </div>
                </div>
              </div>

              {searchResults.products.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No products found. Try a different search term.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {searchResults.products.map((product) => (
                    <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="aspect-square relative">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-foreground mb-1 line-clamp-2">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{product.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-lg font-bold text-primary">
                            ${product.price ? product.price.toFixed(2) : "0.00"}
                          </span>
                          <Badge variant="outline">{product.category}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Loading State */}
          {isLoading && !searchResults && (
            <div className="text-center py-12">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">Searching products...</p>
            </div>
          )}

          {/* Welcome Message */}
          {!searchResults && !isLoading && (
            <div className="text-center py-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">Welcome to Visual Search</h2>
              <p className="text-muted-foreground mb-6">
                Search for products using text, voice commands, or upload images to find similar items.
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge variant="outline">Text Search</Badge>
                <Badge variant="outline">Voice Search</Badge>
                <Badge variant="outline">Image Search</Badge>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Hidden File Input */}
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
    </div>
  )
}
