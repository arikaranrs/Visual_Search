import { type NextRequest, NextResponse } from "next/server"
import { searchWithAlgolia } from "@/lib/services/algolia-service"
import { searchFirestore } from "@/lib/services/firebase-service"
import { config } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    const { query: searchQuery } = await request.json()

    if (!searchQuery || typeof searchQuery !== "string") {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    console.log("[v0] Text search query:", searchQuery)

    let products: any[] = []
    let searchMethod = "firebase"

    // Try Algolia search first if enabled
    if (config.features.useAlgolia && config.algolia.appId && config.algolia.apiKey) {
      try {
        console.log("[v0] Using Algolia search")
        const algoliaResults = await searchWithAlgolia(searchQuery)
        products = algoliaResults.hits || []
        searchMethod = "algolia"
      } catch (algoliaError) {
        console.warn("[v0] Algolia search failed, falling back to Firebase:", algoliaError)
        // Fall back to Firebase search
        products = await searchFirestore(searchQuery)
      }
    } else {
      // Use Firebase search
      console.log("[v0] Using Firebase search")
      products = await searchFirestore(searchQuery)
    }

    console.log(`[v0] Found ${products.length} products using ${searchMethod}`)

    return NextResponse.json({
      products,
      query: searchQuery,
      searchType: "text",
      searchMethod,
      totalResults: products.length,
      processingTime: Date.now(),
    })
  } catch (error) {
    console.error("[v0] Text search error:", error)
    return NextResponse.json(
      {
        error: "Search failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
