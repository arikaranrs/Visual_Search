import { type NextRequest, NextResponse } from "next/server"
import { analyzeImageWithEnhancedCNN, extractEnhancedSearchKeywords } from "@/lib/services/vision-service"
import { searchSimilarProducts } from "@/lib/services/firebase-service"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const image = formData.get("image") as File

    if (!image) {
      return NextResponse.json({ error: "Image is required" }, { status: 400 })
    }

    console.log("[v0] Enhanced image search - file size:", image.size, "type:", image.type)

    const visionAnalysis = await analyzeImageWithEnhancedCNN(image)
    const searchKeywords = extractEnhancedSearchKeywords(visionAnalysis)

    console.log("[v0] Enhanced vision analysis - keywords:", searchKeywords)
    console.log("[v0] Analysis confidence:", visionAnalysis.confidence)

    const searchResults = await searchSimilarProducts(searchKeywords, 0.3) // 30% minimum similarity

    console.log(`[v0] Found ${searchResults.totalResults} similar products`)

    return NextResponse.json({
      products: searchResults.products,
      query: "Enhanced Image Search",
      searchType: "image",
      searchMethod: searchResults.searchMethod,
      visionAnalysis: {
        confidence: visionAnalysis.confidence,
        productCategories: visionAnalysis.productCategories,
        colorAnalysis: visionAnalysis.colorAnalysis,
        totalLabels: visionAnalysis.labels.length,
        totalObjects: visionAnalysis.objects.length,
      },
      searchKeywords,
      performance: {
        totalResults: searchResults.totalResults,
        averageConfidence: searchResults.confidence,
        highConfidenceResults: searchResults.products.filter((p) => p.similarityScore > 0.7).length,
        processingTime: Date.now(),
      },
    })
  } catch (error) {
    console.error("[v0] Enhanced image search error:", error)
    return NextResponse.json(
      {
        error: "Enhanced image search failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
