import { type NextRequest, NextResponse } from "next/server"
import { config } from "@/lib/config"
import { testVisionAPI } from "@/lib/services/vision-service"

export async function GET(request: NextRequest) {
  try {
    const health = {
      status: "healthy",
      timestamp: new Date().toISOString(),
      services: {
        firebase: {
          configured: !!(config.firebase.public.projectId && config.firebase.public.apiKey),
          status: "unknown",
        },
        algolia: {
          configured: !!(config.algolia.appId && config.algolia.apiKey),
          enabled: config.features.useAlgolia,
          status: "unknown",
        },
        googleVision: {
          configured: !!(config.googleVision.apiKey || config.googleVision.credentials),
          enabled: config.features.useVisionApi,
          status: "unknown",
          apiKey: !!config.googleVision.apiKey,
          serviceAccount: !!config.googleVision.credentials,
          projectId: config.googleVision.projectId,
        },
      },
      features: config.features,
      environment: config.app.nodeEnv,
    }

    // Test Firebase connection
    try {
      // Simple test - we'll implement actual connectivity test later
      health.services.firebase.status = health.services.firebase.configured ? "configured" : "not_configured"
    } catch (error) {
      health.services.firebase.status = "error"
    }

    // Test Algolia connection
    try {
      health.services.algolia.status = health.services.algolia.configured ? "configured" : "not_configured"
    } catch (error) {
      health.services.algolia.status = "error"
    }

    // Test Google Vision
    try {
      health.services.googleVision.status = health.services.googleVision.configured ? "configured" : "not_configured"
    } catch (error) {
      health.services.googleVision.status = "error"
    }

    console.log("Testing Google Vision API connectivity...")
    try {
      const visionTest = await testVisionAPI()
      health.services.googleVision.status = visionTest.success ? "healthy" : "error"
      if (!visionTest.success) {
        console.warn("Vision API test failed:", visionTest.error)
      }
    } catch (error) {
      health.services.googleVision.status = "error"
      console.error("Vision API test error:", error)
    }

    return NextResponse.json(health)
  } catch (error) {
    console.error("[v0] Health check error:", error)
    return NextResponse.json(
      {
        status: "unhealthy",
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
