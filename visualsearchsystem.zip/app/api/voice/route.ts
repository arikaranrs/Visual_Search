import { type NextRequest, NextResponse } from "next/server"
import { searchWithAlgolia } from "@/lib/services/algolia-service"
import { searchFirestore } from "@/lib/services/firebase-service"
import { config } from "@/lib/config"

export async function POST(request: NextRequest) {
  try {
    const { transcript } = await request.json()

    if (!transcript || typeof transcript !== "string") {
      return NextResponse.json({ error: "Transcript is required" }, { status: 400 })
    }

    console.log("[v0] Voice search transcript:", transcript)

    // Process voice transcript - could add NLP processing here
    const processedQuery = transcript.toLowerCase().trim()

    let products: any[] = []
    let searchMethod = "firebase"

    // Try Algolia search first if enabled
    if (config.features.useAlgolia && config.algolia.appId && config.algolia.apiKey) {
      try {
        console.log("[v0] Using Algolia search for voice")
        const algoliaResults = await searchWithAlgolia(processedQuery)
        products = algoliaResults.hits || []
        searchMethod = "algolia"
      } catch (algoliaError) {
        console.warn("[v0] Algolia search failed, falling back to Firebase:", algoliaError)
        products = await searchFirestore(processedQuery)
      }
    } else {
      console.log("[v0] Using Firebase search for voice")
      products = await searchFirestore(processedQuery)
    }

    console.log(`[v0] Voice search found ${products.length} products using ${searchMethod}`)

    return NextResponse.json({
      products,
      query: transcript,
      searchType: "voice",
      searchMethod,
      totalResults: products.length,
      processingTime: Date.now(),
    })
  } catch (error) {
    console.error("[v0] Voice search error:", error)
    return NextResponse.json(
      {
        error: "Voice search failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
